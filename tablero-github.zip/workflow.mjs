export const ACTIVITY_STATES = Object.freeze([
  'Pendiente',
  'Asignada',
  'En proceso',
  'En revisión',
  'Observada',
  'Finalizada',
  'Cancelada',
  'Atrasada',
]);

export const ACTIVITY_PRIORITIES = Object.freeze(['Baja', 'Media', 'Alta', 'Urgente']);

const LEGACY_STATUS_MAP = Object.freeze({
  'En curso': 'En proceso',
  'Completada': 'Finalizada',
  'Bloqueada': 'Observada',
});

const LEGACY_PRIORITY_MAP = Object.freeze({ Normal: 'Media' });

export function normalizeActivityPriority(value) {
  if (!value) return 'Media';
  return LEGACY_PRIORITY_MAP[value] || value;
}

export function normalizeActivityStatus(value) {
  if (!value) return 'Pendiente';
  return LEGACY_STATUS_MAP[value] || value;
}

function dayKey(value) {
  if (value instanceof Date) {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, '0');
    const day = String(value.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  return String(value ?? '').slice(0, 10);
}

export function statusForActivity(activity, today = new Date()) {
  const status = normalizeActivityStatus(activity?.status ?? activity?.estado);
  if (status === 'Finalizada' || status === 'Cancelada') return status;

  const due = dayKey(activity?.due ?? activity?.fecha_limite);
  const currentDay = dayKey(today);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(due) || !/^\d{4}-\d{2}-\d{2}$/.test(currentDay)) return status;
  return due < currentDay ? 'Atrasada' : status;
}

export function canFinalizeActivity(activity) {
  const checklist = activity?.checklist ?? activity?.requirements ?? [];
  if (!Array.isArray(checklist)) return true;
  return checklist.every((item) => !item?.required || item.completed === true);
}
