# Tablero Contable — Estudio

Tablero web de tareas para un equipo de contabilidad. Muestra las tareas del equipo en kanban, lista y calendario mensual, con clientes, plantillas de checklist, roles (admin / supervisor / worker), alertas de "Requiere atención" y generación automática del flujo mensual por cliente.

- App en producción: https://conta-equipo-tablero.netlify.app
- Backend: Appwrite Cloud (base de datos, autenticación, equipos y una función serverless).

## Estructura

```
.
├── index.html                      # Página principal (HTML + CSS)
├── appwrite-client.js              # Código fuente del cliente (ESM)
├── workflow.mjs                    # Reglas de estados, prioridades y permisos
├── public/                         # Lo que se publica (generado por el build)
│   ├── index.html
│   └── appwrite-client.bundle.js
├── functions/activity-service/     # Función serverless (Node.js)
│   ├── main.mjs                    # Rutas: create, update, comment, members, generate, client.update
│   ├── domain.mjs                  # Autorización por rol y validaciones
│   └── *.test.mjs                  # 16 pruebas de la función
├── scripts/sync-public.mjs         # Copia index.html a public/
├── tests/                          # 15 pruebas del tablero (Python)
├── data/tesoreria-seed.json        # Datos de obligaciones de tesorería
└── appwrite-schema.json            # IDs y esquema de Appwrite
```

## Requisitos

- Node.js 20 o superior y npm
- Python 3 (solo para las pruebas del tablero y para servir archivos localmente)
- Una cuenta de Appwrite Cloud con el proyecto y la base ya creados

## Instalación

```bash
npm install
```

## Desarrollo local

```bash
npm run build      # genera appwrite-client.bundle.js y sincroniza public/
npm start          # sirve public/ en http://localhost:4173
```

Abre `http://localhost:4173`. Para que el login funcione, el origen debe estar registrado como plataforma Web en Appwrite (por ejemplo `localhost`).

## Pruebas

```bash
npm run build
node --test functions/activity-service/*.test.mjs   # 16 pruebas
python -m unittest discover -s tests                # 15 pruebas
```

## Publicar el frontend

El sitio es estático: se publica la carpeta `public/`.

```bash
npm run build
netlify deploy --prod --dir public
```

## Publicar la función de Appwrite

La función necesita `main.mjs`, `domain.mjs` y `package.json` en la raíz del paquete:

```bash
cd functions/activity-service
tar -czf ../../dist/activity-service.tar.gz main.mjs domain.mjs package.json
```

Luego se sube desde la consola de Appwrite (Functions → activity-service → Deployments → Create deployment, tipo manual, runtime Node.js, entrypoint `main.mjs`).

## Configuración de Appwrite

Los identificadores públicos están en `appwrite-client.js` y en `appwrite-schema.json`:

| Recurso           | ID                                 |
|-------------------|------------------------------------|
| Endpoint          | `https://nyc.cloud.appwrite.io/v1` |
| Proyecto          | `6afee68c00094aaf5aca`             |
| Base de datos     | `6afee7d600290b7c3a53`             |
| Tabla de tareas   | `6afee819003db9380092`             |
| Equipo            | `6b00345f00250c3d5dac`             |
| Función           | `activity-service`                 |

La función usa variables de entorno para la API key (`APPWRITE_API_KEY`) y los IDs de tablas; se configuran en la consola de Appwrite, nunca en el repositorio.

## Seguridad

- **No subir nunca** `appwrite-key.txt` ni claves API al repositorio. Están excluidas por `.gitignore`.
- El cliente no contiene claves: solo IDs públicos de proyecto y base.
- La autorización real por rol se aplica en la función serverless, no en el navegador.

## Licencia

Uso interno del estudio. Todos los derechos reservados.
