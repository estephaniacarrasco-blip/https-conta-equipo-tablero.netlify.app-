import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "appwrite-client.js").read_text(encoding="utf-8")


class AppwriteInteractionTests(unittest.TestCase):
    def test_unauthenticated_users_are_prompted_to_sign_in(self):
        self.assertIn("showLogin(error)", JS)
        self.assertIn("createEmailPasswordSession", JS)

    def test_member_filters_and_assignee_choices_load_from_team_memberships(self):
        self.assertIn("teams.list({ queries: [], total: false })", JS)
        self.assertIn("#team-selector", JS)
        self.assertIn("availableTeams.length === 1", JS)
        self.assertIn(".filter((membership) => membership.joined)", JS)
        self.assertIn("membership.userName", JS)
        self.assertNotIn("const TEAM_ID =", JS)
        self.assertIn('appwrite-client.bundle.js?v=', HTML)
        self.assertNotIn("<option>Camila Rojas</option>", HTML)
        self.assertNotIn("<option>Diego Muñoz</option>", HTML)

    def test_all_activity_writes_use_the_authenticated_backend_function(self):
        self.assertIn("new Functions(client)", JS)
        self.assertIn("functions.createExecution", JS)
        self.assertNotIn("tables.createRow(", JS)
        self.assertNotIn("tables.updateRow(", JS)
        self.assertIn("expectedUpdatedAt", JS)
        self.assertIn("responsable_id", JS)

    def test_comment_realtime_channel_is_subscribed(self):
        self.assertIn("Channel.tablesdb(DATABASE_ID).table(COMMENTS_TABLE_ID).row()", JS)
        self.assertIn("scheduleRefresh", JS)


if __name__ == "__main__":
    unittest.main()
