import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "appwrite-client.js").read_text(encoding="utf-8") if (ROOT / "appwrite-client.js").exists() else ""


class AppwriteIntegrationTests(unittest.TestCase):
    def test_board_uses_authenticated_appwrite_data_and_realtime(self):
        self.assertIn("appwrite-client.bundle.js", HTML)
        self.assertIn("https://nyc.cloud.appwrite.io/v1", JS)
        self.assertIn("6afee68c00094aaf5aca", JS)
        self.assertNotIn("6afee8cc00094aaf5aca", JS)
        self.assertIn("createEmailPasswordSession", JS)
        self.assertIn("listRows", JS)
        self.assertIn("createExecution", JS)
        self.assertIn("action: 'create'", JS)
        self.assertIn("action: 'update'", JS)
        self.assertNotIn("createRow", JS)
        self.assertNotIn("updateRow", JS)
        self.assertIn("Realtime", JS)
        self.assertIn("sync-status", HTML)
        self.assertNotIn("localStorage", JS)
        self.assertNotIn("const seed", JS)


if __name__ == "__main__":
    unittest.main()
