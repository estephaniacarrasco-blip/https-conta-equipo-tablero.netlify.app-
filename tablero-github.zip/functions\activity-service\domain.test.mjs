import test from 'node:test';
import assert from 'node:assert/strict';
import {
  authorizeMutation,
  buildChangeSet,
  validateActivityInput,
} from './domain.mjs';

const assignedActivity = {
  $id: 'task-1',
  responsable: 'Trabajadora Uno',
  responsable_id: 'user-1',
  colaboradores_ids: '["user-2"]',
  estado: 'Asignada',
  prioridad: 'Media',
  checklist: '[{"texto":"Revisar respaldo","obligatorio":true,"completado":false}]',
};

test('worker can advance the status of an assigned activity', () => {
  assert.doesNotThrow(() => authorizeMutation({
    role: 'worker',
    actor: { id: 'user-2', name: 'Trabajador Dos' },
    action: 'update',
    activity: assignedActivity,
    patch: { estado: 'En proceso' },
  }));
});

test('worker cannot edit fields outside progress or change another activity', () => {
  assert.throws(() => authorizeMutation({
    role: 'worker',
    actor: { id: 'user-2', name: 'Trabajador Dos' },
    action: 'update',
    activity: assignedActivity,
    patch: { prioridad: 'Urgente' },
  }), { status: 403 });
  assert.throws(() => authorizeMutation({
    role: 'worker',
    actor: { id: 'user-3', name: 'Otra Persona' },
    action: 'update',
    activity: assignedActivity,
    patch: { estado: 'En proceso' },
  }), { status: 403 });
});

test('required checklist items block finalization for every role', () => {
  assert.throws(() => authorizeMutation({
    role: 'admin',
    actor: { id: 'admin-1', name: 'Admin' },
    action: 'update',
    activity: assignedActivity,
    patch: { estado: 'Finalizada' },
  }), { status: 409 });
});

test('activity input accepts only configured states and priorities', () => {
  assert.doesNotThrow(() => validateActivityInput({
    titulo: 'Preparar F29',
    estado: 'Pendiente',
    prioridad: 'Urgente',
    fecha_limite: '2026-12-20T12:00:00.000Z',
  }));
  assert.throws(() => validateActivityInput({
    titulo: 'Preparar F29',
    estado: 'Desconocido',
    prioridad: 'Normal',
    fecha_limite: '2026-12-20T12:00:00.000Z',
  }), { status: 400 });
});

test('change set records only fields that actually changed', () => {
  assert.deepEqual(buildChangeSet(
    { estado: 'Pendiente', prioridad: 'Media' },
    { estado: 'En proceso', prioridad: 'Media' },
  ), { estado: { anterior: 'Pendiente', nuevo: 'En proceso' } });
});

test('supervisor can create activities and edit someone else\'s task', () => {
  assert.doesNotThrow(() => authorizeMutation({
    role: 'supervisor',
    actor: { id: 'user-9', name: 'Supervisora' },
    action: 'create',
    patch: {
      titulo: 'Conciliar banco', estado: 'Asignada', prioridad: 'Media',
      fecha_limite: '2026-12-05T12:00:00.000Z', responsable: 'Trabajadora Uno',
      responsable_id: 'user-1', colaboradores_ids: [],
    },
  }));
  assert.doesNotThrow(() => authorizeMutation({
    role: 'supervisor',
    actor: { id: 'user-9', name: 'Supervisora' },
    action: 'update',
    activity: assignedActivity,
    patch: { prioridad: 'Alta' },
  }));
});

test('worker still cannot create activities or touch a task that is not theirs', () => {
  assert.throws(() => authorizeMutation({
    role: 'worker',
    actor: { id: 'user-2', name: 'Trabajador Dos' },
    action: 'create',
    patch: { titulo: 'X' },
  }), /administración o supervisión/);
  assert.throws(() => authorizeMutation({
    role: 'worker',
    actor: { id: 'user-3', name: 'Ajeno' },
    action: 'update',
    activity: assignedActivity,
    patch: { estado: 'En proceso' },
  }), /No tienes acceso/);
});
