const STATUS_VALUES = new Set([
  'Pendiente', 'Asignada', 'En proceso', 'En revisión',
  'Observada', 'Finalizada', 'Cancelada', 'Atrasada',
]);
const PRIORITY_VALUES = new Set(['Baja', 'Media', 'Alta', 'Urgente']);
const ADMIN_FIELDS = new Set([
  'titulo', 'cliente', 'responsable', 'responsable_id', 'colaboradores_ids',
  'fecha_inicio', 'fecha_limite', 'estado', 'prioridad', 'descripcion',
  'departamento', 'categoria', 'checklist',
]);
const WORKER_STATUSES = new Set(['En proceso', 'En revisión', 'Finalizada']);

export class DomainError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'DomainError';
    this.status = status;
  }
}

function toArray(value) {
  if (Array.isArray(value)) return value;
  if (typeof value !== 'string' || !value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function validateActivityInput(input = {}) {
  const title = String(input.titulo ?? '').trim();
  const status = String(input.estado ?? 'Pendiente');
  const priority = String(input.prioridad ?? 'Media');
  const due = String(input.fecha_limite ?? '');
  if (!title || title.length > 255) throw new DomainError('El título es obligatorio y debe tener hasta 255 caracteres.');
  if (!STATUS_VALUES.has(status)) throw new DomainError('Estado no válido.');
  if (!PRIORITY_VALUES.has(priority)) throw new DomainError('Prioridad no válida.');
  if (!due || !Number.isFinite(Date.parse(due))) throw new DomainError('La fecha límite no es válida.');
  if (input.descripcion && String(input.descripcion).length > 50000) throw new DomainError('La descripción excede el largo permitido.');
  const collaborators = toArray(input.colaboradores_ids);
  if (collaborators.some((id) => typeof id !== 'string' || id.length > 36)) {
    throw new DomainError('La lista de colaboradores no es válida.');
  }
  const checklist = toArray(input.checklist);
  if (checklist.some((item) => !item || typeof item !== 'object' || typeof item.texto !== 'string')) {
    throw new DomainError('La lista de requisitos no es válida.');
  }
  return true;
}

export function canFinalizeActivity(activity = {}) {
  return toArray(activity.checklist).every((item) =>
    !item.obligatorio || item.completado === true,
  );
}

export function isAssignedTo(activity = {}, actor = {}) {
  const ids = [activity.responsable_id, ...toArray(activity.colaboradores_ids)];
  if (actor.id && ids.includes(actor.id)) return true;
  return Boolean(actor.name && activity.responsable === actor.name);
}

export function authorizeMutation({ role, actor, action, activity = {}, patch = {} }) {
  if (!['admin', 'supervisor', 'worker'].includes(role)) throw new DomainError('Rol sin autorización.', 403);
  if (action === 'create') {
    if (!['admin', 'supervisor'].includes(role)) throw new DomainError('Solo administración o supervisión puede crear actividades.', 403);
    validateActivityInput(patch);
    if (patch.estado === 'Finalizada' && !canFinalizeActivity(patch)) {
      throw new DomainError('Quedan requisitos obligatorios pendientes.', 409);
    }
    return true;
  }
  if (action === 'comment') {
    if (role !== 'admin' && !isAssignedTo(activity, actor)) {
      throw new DomainError('No tienes acceso a esta actividad.', 403);
    }
    return true;
  }
  if (action !== 'update') throw new DomainError('Operación no permitida.', 400);
  const keys = Object.keys(patch);
  if (!keys.length || keys.some((key) => !ADMIN_FIELDS.has(key))) {
    throw new DomainError('La actualización contiene campos no permitidos.', 400);
  }
  if (role === 'worker') {
    if (!isAssignedTo(activity, actor)) throw new DomainError('No tienes acceso a esta actividad.', 403);
    if (keys.length !== 1 || keys[0] !== 'estado') {
      throw new DomainError('Trabajadores solo pueden actualizar el estado.', 403);
    }
    if (!WORKER_STATUSES.has(patch.estado)) throw new DomainError('Ese cambio de estado requiere revisión administrativa.', 403);
  }
  if (patch.estado && !STATUS_VALUES.has(patch.estado)) throw new DomainError('Estado no válido.');
  if (patch.prioridad && !PRIORITY_VALUES.has(patch.prioridad)) throw new DomainError('Prioridad no válida.');
  if (patch.estado === 'Finalizada' && !canFinalizeActivity(activity)) {
    throw new DomainError('Quedan requisitos obligatorios pendientes.', 409);
  }
  return true;
}

export function buildChangeSet(before = {}, after = {}) {
  const changes = {};
  for (const [key, value] of Object.entries(after)) {
    const oldValue = before[key] ?? null;
    const same = JSON.stringify(oldValue) === JSON.stringify(value ?? null);
    if (!same) changes[key] = { anterior: oldValue, nuevo: value ?? null };
  }
  return changes;
}
