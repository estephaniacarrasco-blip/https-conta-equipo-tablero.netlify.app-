// Copia a public/ solo los archivos que el navegador debe poder descargar.
// El resto del proyecto (claves, tests, funciones, datos) queda fuera del servidor.
import { copyFile, mkdir } from 'node:fs/promises';

const files = ['index.html', 'appwrite-client.bundle.js'];
await mkdir('public', { recursive: true });
for (const file of files) {
  await copyFile(file, `public/${file}`);
  console.log(`public/${file}`);
}
