from pathlib import Path
import unittest

HTML = (Path(__file__).resolve().parent.parent / 'index.html').read_text(encoding='utf-8')
JS = (Path(__file__).resolve().parent.parent / 'appwrite-client.js').read_text(encoding='utf-8')

class DashboardSkeletonTests(unittest.TestCase):
    def test_has_team_task_board_and_create_task_action(self):
        self.assertIn('Todas las tareas', HTML)
        self.assertIn('Nueva tarea', HTML)
        self.assertIn('id="task-form"', HTML)

    def test_has_filters_and_local_persistence(self):
        self.assertIn('id="search"', HTML)
        self.assertIn('id="owner-filter"', HTML)
        self.assertIn('tables.listRows', JS)
        self.assertIn("action: 'create'", JS)
        self.assertIn("action: 'update'", JS)
        self.assertNotIn('tables.createRow', JS)
        self.assertNotIn('tables.updateRow', JS)
        self.assertNotIn('localStorage', JS)

    def test_supports_status_changes_and_task_comments(self):
        self.assertIn('En revisión', HTML)
        self.assertIn('Comentarios', HTML)

    def test_new_activity_form_exposes_the_requested_workflow_and_priority(self):
        for value in ['Pendiente', 'Asignada', 'En proceso', 'En revisión', 'Observada', 'Finalizada', 'Cancelada', 'Atrasada']:
            self.assertRegex(HTML, rf'<option(?:\s[^>]*)?>{value}</option>')
        for value in ['Baja', 'Media', 'Alta', 'Urgente']:
            self.assertRegex(HTML, rf'<option(?:\s[^>]*)?>{value}</option>')
        self.assertIn('name="priority"', HTML)

if __name__ == '__main__':
    unittest.main()
