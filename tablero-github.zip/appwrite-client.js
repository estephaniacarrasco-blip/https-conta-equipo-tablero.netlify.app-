import { Account, Channel, Client, Functions, Query, Realtime, TablesDB, Teams } from 'appwrite';
import { ACTIVITY_PRIORITIES, ACTIVITY_STATES, canFinalizeActivity, normalizeActivityPriority, normalizeActivityStatus, statusForActivity } from './workflow.mjs';

const ENDPOINT = 'https://nyc.cloud.appwrite.io/v1';
const PROJECT_ID = '6afee68c00094aaf5aca';
const DATABASE_ID = '6afee7d600290b7c3a53';
const TABLE_ID = '6afee819003db9380092';
const COMMENTS_TABLE_ID = 'activity_comments';
const CLIENTS_TABLE_ID = 'clientes';
const FUNCTION_ID = 'activity-service';
const STATES = ACTIVITY_STATES;
const $ = (selector) => document.querySelector(selector);
const client = new Client().setEndpoint(ENDPOINT).setProject(PROJECT_ID);
const account = new Account(client);
const functions = new Functions(client);
const tables = new TablesDB(client);
const teams = new Teams(client);
const realtime = new Realtime(client);

let rows = [];
let clientes = [];
let templates = [];
let savedViews = [];
let userPrefs = {};
let members = [];
let teamMembers = [];
let activeTeamId;
let currentUserId = '';
let currentUserLabel = '';
let currentRole = 'worker';
let subscription;
let commentsSubscription;
let membershipSubscription;
let refreshTimer;
let refreshPromise;
let refreshQueued = false;

const filters = { q: '', owner: '', client: '', state: '' };
let mode = 'lista';
let quickFilter = 'todas';
let calDate = startOfMonth(new Date());
const expandedDays = new Set();

const DATE_FMT = new Intl.DateTimeFormat('es-CL', { day: '2-digit', month: 'short' });
const MONTH_FMT = new Intl.DateTimeFormat('es-CL', { month: 'long', year: 'numeric' });
const DAY_NAMES = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

function startOfMonth(date) { const d = new Date(date); d.setDate(1); d.setHours(0, 0, 0, 0); return d; }
function isoDay(date) {
  const y = date.getFullYear(); const m = String(date.getMonth() + 1).padStart(2, '0'); const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}
function todayIso() { return isoDay(new Date()); }
function isDone(task) { return task.status === 'Finalizada' || task.status === 'Cancelada'; }
function isOverdue(task) { return !isDone(task) && task.due && task.due < todayIso(); }
function priorityRank(task) { return { Urgente: 0, Alta: 1, Media: 2, Baja: 3 }[task.priority] ?? 2; }
function sortTasks(a, b) {
  return priorityRank(a) - priorityRank(b) || String(a.due || '9999').localeCompare(String(b.due || '9999'));
}
function canEditTask(task) {
  if (['admin', 'supervisor'].includes(currentRole)) return true;
  return Boolean(task.responsibleId && task.responsibleId === currentUserId);
}

function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} tardó más de ${Math.round(ms / 1000)} s. Revisa tu conexión.`)), ms)),
  ]);
}
function notify(message) {
  let box = $('#app-message');
  if (!box) {
    box = document.createElement('p');
    box.id = 'app-message';
    box.setAttribute('role', 'status');
    box.style.cssText = 'padding:10px 14px;border-radius:8px;background:#fff0e8;color:#783c13;margin:10px 0';
    $('.app').prepend(box);
  }
  box.textContent = message;
}
function setSyncStatus(text, state = 'connected') {
  const badge = $('#sync-status');
  if (!badge) return;
  badge.textContent = text;
  badge.dataset.state = state;
}
async function executeActivityService(payload) {
  const execution = await functions.createExecution({
    functionId: FUNCTION_ID,
    body: JSON.stringify(payload),
    async: false,
  });
  let response = {};
  try { response = JSON.parse(execution.responseBody || '{}'); }
  catch { throw new Error('El servicio devolvió una respuesta no válida.'); }
  const status = Number(execution.responseStatusCode || 0);
  if (status < 200 || status >= 300 || response.ok === false) {
    throw new Error(response.error || `El servicio respondió HTTP ${status || 'desconocido'}.`);
  }
  return response;
}
function checklistFromLines(value) {
  return String(value || '').split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => {
    const obligatorio = line.startsWith('*');
    return { texto: obligatorio ? line.slice(1).trim() : line, obligatorio, completado: false };
  }).filter((item) => item.texto);
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[char]);
}
function jsonArray(value) {
  if (Array.isArray(value)) return value;
  try { const parsed = JSON.parse(value || '[]'); return Array.isArray(parsed) ? parsed : []; }
  catch { return []; }
}
function fromRow(row) {
  const task = {
    id: row.$id,
    updatedAt: row.$updatedAt,
    title: row.titulo,
    client: row.cliente || '',
    clientId: row.cliente_id || '',
    owner: row.responsable || 'Sin asignar',
    responsibleId: row.responsable_id || '',
    collaboratorIds: jsonArray(row.colaboradores_ids),
    due: row.fecha_limite ? row.fecha_limite.slice(0, 10) : '',
    start: row.fecha_inicio ? row.fecha_inicio.slice(0, 10) : '',
    startReal: row.fecha_inicio_real ? row.fecha_inicio_real.slice(0, 10) : '',
    endReal: row.fecha_fin_real ? row.fecha_fin_real.slice(0, 10) : '',
    onTime: row.cerrada_a_tiempo === true,
    reprocesoCount: Number(row.reproceso_count || 0),
    lastReproceso: row.ultimo_reproceso_tipo || '',
    status: normalizeActivityStatus(row.estado),
    priority: normalizeActivityPriority(row.prioridad),
    description: row.descripcion || '',
    department: row.departamento || '',
    category: row.categoria || '',
    comments: Array.isArray(row.__comments) ? row.__comments : [],
    checklist: jsonArray(row.checklist),
  };
  task.overdue = !isDone(task) && Boolean(task.due) && task.due < todayIso();
  return task;
}

async function loadMembers(preferredTeamId = activeTeamId) {
  const teamList = await teams.list({ queries: [], total: false });
  const availableTeams = teamList.teams || [];
  const selector = $('#team-selector');
  if (!availableTeams.length) {
    selector.innerHTML = '<option value="">Sin equipos disponibles</option>';
    activeTeamId = undefined;
    throw new Error('Esta cuenta no pertenece a ningún equipo de Appwrite. Deben invitarla y confirmar la membresía en la consola Appwrite.');
  }
  selector.innerHTML = availableTeams.map((team) => `<option value="${escapeHtml(team.$id)}">${escapeHtml(team.name)}</option>`).join('');
  const team = availableTeams.find((item) => item.$id === preferredTeamId)
    || availableTeams.find((item) => item.name.trim().toLocaleLowerCase() === 'equipo contable')
    || (availableTeams.length === 1 ? availableTeams[0] : null);
  if (!team) {
    selector.value = '';
    throw new Error('Tu cuenta tiene varios equipos. Selecciona el equipo correcto en el menú superior.');
  }
  activeTeamId = team.$id;
  selector.value = activeTeamId;
  const result = await teams.listMemberships({ teamId: activeTeamId, queries: [], total: false });
  const joined = result.memberships.filter((membership) => membership.joined);
  const ownMembership = joined.find((membership) => membership.userId === currentUserId);
  let roster = [];
  try {
    const rosterResponse = await executeActivityService({ action: 'members' });
    roster = Array.isArray(rosterResponse.members) ? rosterResponse.members : [];
  } catch (error) { roster = []; }
  if (!roster.length) {
    roster = joined.map((membership) => ({
      userId: membership.userId,
      nombre: membership.userName || membership.userEmail || '',
      roles: membership.roles || [],
    }));
  }
  teamMembers = roster
    .filter((member) => member && member.userId && member.nombre)
    .map((member) => ({ id: member.userId, name: member.nombre, roles: member.roles || [] }));
  members = [...new Set(teamMembers.map((member) => member.name))];
  const ownRoles = ownMembership?.roles || teamMembers.find((member) => member.id === currentUserId)?.roles || [];
  currentRole = ownRoles.includes('admin') ? 'admin' : ownRoles.includes('supervisor') ? 'supervisor' : 'worker';
  $('#new-task').hidden = !['admin', 'supervisor'].includes(currentRole);
  const ownerSelect = document.querySelector('#task-form [name="owner"]');
  ownerSelect.innerHTML = '<option value="" disabled selected>Selecciona responsable</option>'
    + teamMembers.map((member) => `<option value="${escapeHtml(member.id)}">${escapeHtml(member.name)}</option>`).join('');
  const collaboratorSelect = document.querySelector('#task-form [name="collaborators"]');
  if (collaboratorSelect) collaboratorSelect.innerHTML = teamMembers.map((member) => `<option value="${escapeHtml(member.id)}">${escapeHtml(member.name)}</option>`).join('');
  selector.selectedOptions[0].textContent = `${team.name} · ${members.length} personas`;
}

async function loadRows() {
  const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLE_ID, queries: [Query.limit(200)] });
  let comments = [];
  try {
    const commentRows = await tables.listRows({ databaseId: DATABASE_ID, tableId: COMMENTS_TABLE_ID, queries: [Query.orderAsc('fecha'), Query.limit(500)] });
    comments = commentRows.rows || [];
  } catch (error) { comments = []; }
  const byActivity = new Map();
  for (const comment of comments) {
    const key = comment.actividad_id || '';
    if (!byActivity.has(key)) byActivity.set(key, []);
    byActivity.get(key).push(comment);
  }
  rows = (result.rows || []).map((row) => fromRow({ ...row, __comments: byActivity.get(row.$id) || [] }));
  render();
}

async function loadClientes() {
  try {
    const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: CLIENTS_TABLE_ID, queries: [Query.limit(100)] });
    clientes = (result.rows || []).map((row) => ({
      id: row.$id,
      nombre: row.nombre,
      estado: row.estado || 'activo',
      notas: row.notas || '',
      frecuencia: row.frecuencia || 'mensual',
      plantillaId: row.plantilla_id || '',
      diaVencimiento: Number(row.dia_vencimiento || 5),
      duenoId: row.dueno_relacion_id || '',
      responsableId: row.responsable_ejecucion_id || '',
      revisorId: row.revisor_id || '',
    }));
  } catch (error) { clientes = []; }
  return clientes;
}
async function loadTemplates() {
  if (templates.length) return templates;
  try {
    const result = await tables.listRows({ databaseId: DATABASE_ID, tableId: 'checklist_plantillas', queries: [Query.limit(100)] });
    templates = (result.rows || []).map((row) => ({ id: row.$id, nombre: row.nombre, items: jsonArray(row.items) }));
  } catch (error) { templates = []; }
  return templates;
}

function scheduleRefresh() {
  setSyncStatus('Sincronizando…', 'syncing');
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => refresh(), 150);
}
async function refresh() {
  if (refreshPromise) { refreshQueued = true; return refreshPromise; }
  refreshPromise = (async () => {
    do { refreshQueued = false; await loadRows(); } while (refreshQueued);
  })();
  try {
    await refreshPromise;
    setSyncStatus('En vivo', 'connected');
  } catch (error) {
    setSyncStatus('Sin conexión', 'error');
    notify(`No se pudieron cargar las tareas: ${error.message}`);
  } finally {
    refreshPromise = null;
  }
}

/* ---------------- router ---------------- */

function currentRoute() {
  const name = (location.hash || '').replace('#/', '').split('?')[0];
  if (['mi-dia', 'equipo', 'clientes'].includes(name)) return name;
  return ['admin', 'supervisor'].includes(currentRole) ? 'equipo' : 'mi-dia';
}
function go(route) {
  if (currentRoute() === route) { render(); return; }
  location.hash = `#/${route}`;
}
function render() {
  const route = currentRoute();
  document.querySelectorAll('nav.views button').forEach((button) => {
    if (button.dataset.route === route) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  const title = $('#page-title');
  if (route === 'mi-dia') title.textContent = 'Mi día';
  else if (route === 'clientes') title.textContent = 'Clientes';
  else title.textContent = 'Vista del equipo';
  if (route === 'mi-dia') renderMyDay();
  else if (route === 'clientes') renderClients();
  else renderTeam();
}

/* ---------------- shared bits ---------------- */

function statusPill(status) {
  const cls = status === 'En proceso' ? 'proceso' : status === 'En revisión' ? 'revision' : status.replace(/\s/g, '');
  return `<span class="pill ${escapeHtml(cls)}">${escapeHtml(status)}</span>`;
}
function initials(name) {
  const clean = String(name || '').trim();
  if (!clean || /^sin asignar$/i.test(clean)) return '—';
  const parts = clean.split(/\s+/).filter(Boolean).slice(0, 2);
  return parts.map((part) => part[0]).join('').toUpperCase();
}
function taskCard(task) {
  const overdue = isOverdue(task);
  const prio = String(task.priority || 'Media');
  return `<article class="task" data-state="${escapeHtml(task.status)}" data-prio="${escapeHtml(prio)}" data-overdue="${overdue}" data-task="${escapeHtml(task.id)}" title="${escapeHtml(task.title)}${task.client ? ' · ' + escapeHtml(task.client) : ''}">
    <div class="task-title">${escapeHtml(task.title)}</div>
    <div class="task-foot">
      <span class="due${overdue ? ' late-txt' : ''}">${task.due ? escapeHtml(task.due.slice(8, 10) + '/' + task.due.slice(5, 7)) : '—'}${overdue ? ' ⚠' : ''}</span>
      <span class="avatar-mini" title="${escapeHtml(task.owner)}">${escapeHtml(initials(task.owner))}</span>
    </div>
  </article>`;
}

/* ---------------- Mi día ---------------- */

function myTasks() {
  return rows.filter((task) => task.responsibleId === currentUserId || task.collaboratorIds.includes(currentUserId));
}
function weekRange() {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const monday = new Date(today); monday.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
  return { from: isoDay(monday), to: isoDay(sunday), fromDate: monday, toDate: sunday };
}
function renderMyDay() {
  const mine = myTasks();
  const today = todayIso();
  const week = weekRange();
  const pending = mine.filter((task) => !isDone(task));
  const dueToday = pending.filter((task) => task.due === today);
  const overdue = pending.filter((task) => task.due && task.due < today);
  const closedThisWeek = mine.filter((task) => task.status === 'Finalizada' && task.endReal && task.endReal >= week.from && task.endReal <= week.to);
  const closed = mine.filter((task) => task.status === 'Finalizada');
  const onTime = closed.filter((task) => task.onTime).length;
  const compliance = closed.length ? Math.round((onTime / closed.length) * 100) : 0;
  const inReproceso = mine.filter((task) => task.reprocesoCount > 0 && !isDone(task)).length;

  let visible = pending;
  if (quickFilter === 'hoy') visible = pending.filter((task) => task.due === today);
  else if (quickFilter === 'semana') visible = pending.filter((task) => task.due && task.due >= week.from && task.due <= week.to);
  else if (quickFilter === 'vencidas') visible = overdue;
  else visible = pending;
  visible = visible.slice().sort(sortTasks);

  const tabs = [['hoy', 'Hoy'], ['semana', 'Esta semana'], ['vencidas', 'Vencidas'], ['todas', 'Todas']];
  $('#view').innerHTML = `
    <section class="cards">
      <div class="card accent"><div class="k">Pendientes</div><div class="v">${pending.length}</div></div>
      <div class="card"><div class="k">Vencen hoy</div><div class="v">${dueToday.length}</div></div>
      <div class="card"><div class="k">Vencidas</div><div class="v" style="color:${overdue.length ? 'var(--red)' : 'inherit'}">${overdue.length}</div></div>
      <div class="card"><div class="k">Completadas esta semana</div><div class="v">${closedThisWeek.length}</div></div>
      <div class="card"><div class="k">Cumplimiento</div><div class="v">${compliance}%</div></div>
      <div class="card"><div class="k">En reproceso</div><div class="v">${inReproceso}</div></div>
    </section>
    <div class="toolbar">
      <div class="seg" role="group" aria-label="Filtro rápido">
        ${tabs.map(([key, label]) => `<button type="button" data-quick="${key}" aria-pressed="${quickFilter === key}">${label}</button>`).join('')}
      </div>
      <span class="grow"></span>
      <span class="chip">${visible.length} tarea${visible.length === 1 ? '' : 's'}</span>
    </div>
    <div class="list">
      <div class="row head"><span>Tarea</span><span>Cliente</span><span>Fecha</span><span>Estado</span><span>Acción</span></div>
      ${visible.map((task) => `
        <div class="row" data-task="${escapeHtml(task.id)}">
          <span><b>${escapeHtml(task.title)}</b></span>
          <span class="hide-s">${escapeHtml(task.client || '—')}</span>
          <span class="hide-s">${task.due ? escapeHtml(task.due.slice(8, 10) + '/' + task.due.slice(5, 7)) : '—'}</span>
          <span>${statusPill(task.status)}</span>
          <span class="hide-s">${task.status === 'En proceso' ? `<button class="btn" data-action="finish" data-task="${escapeHtml(task.id)}">Finalizar</button>` : `<button class="btn" data-action="start" data-task="${escapeHtml(task.id)}">Iniciar</button>`}</span>
        </div>`).join('') || '<div class="empty">Sin tareas en este filtro</div>'}
    </div>`;
}

/* ---------------- Vista del equipo ---------------- */

function sameClient(a, b) {
  return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}
function clientKey(task) {
  return String(task.client || '').trim();
}
function visibleRows() {
  const q = filters.q.toLowerCase();
  return rows.filter((task) => {
    if (q && !`${task.title} ${task.client} ${task.owner}`.toLowerCase().includes(q)) return false;
    if (filters.owner && task.owner !== filters.owner) return false;
    if (filters.client && !sameClient(task.client, filters.client)) return false;
    if (filters.state === 'Atrasada' && !task.overdue) return false;
    if (filters.state && filters.state !== 'Atrasada' && task.status !== filters.state) return false;
    return true;
  });
}
function toolbarHtml() {
  const tpl = $('#team-toolbar-tpl');
  const wrap = document.createElement('div');
  wrap.appendChild(tpl.content.cloneNode(true));
  const html = wrap.innerHTML;
  return html;
}
function fillFilters() {
  const ownerFilter = $('#owner-filter');
  const clientFilter = $('#client-filter');
  const stateFilter = $('#state-filter');
  if (ownerFilter) {
    ownerFilter.innerHTML = '<option value="">Todo el equipo</option>'
      + [...new Set(rows.map((task) => task.owner))].sort().map((name) => `<option>${escapeHtml(name)}</option>`).join('');
    ownerFilter.value = filters.owner;
  }
  if (clientFilter) {
    const names = [...new Set([
      ...clientes.map((cliente) => String(cliente.nombre || '').trim()),
      ...rows.map((task) => clientKey(task)),
    ].filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
    clientFilter.innerHTML = '<option value="">Todos los clientes</option>'
      + names.map((name) => `<option value="${escapeHtml(name)}" ${sameClient(name, filters.client) ? 'selected' : ''}>${escapeHtml(name)}</option>`).join('');
    clientFilter.value = filters.client;
  }
  if (stateFilter) {
    stateFilter.innerHTML = '<option value="">Todos los estados</option>' + STATES.map((state) => `<option>${state}</option>`).join('');
    stateFilter.value = filters.state;
  }
  const groupFilter = $('#group-filter');
  if (groupFilter) {
    groupFilter.value = groupBy;
    groupFilter.onchange = () => { groupBy = groupFilter.value; listPage = 1; renderTeamBody(); };
  }
  document.querySelectorAll('.seg [data-mode]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.mode === mode)));
  const clear = $('#clear-filters');
  if (clear && !$('#save-view')) {
    const save = document.createElement('button');
    save.className = 'btn';
    save.id = 'save-view';
    save.type = 'button';
    save.textContent = 'Guardar vista';
    save.onclick = async () => {
      const nombre = prompt('Nombre de la vista (ej. "Mis tareas en revisión")');
      if (!nombre) return;
      const vista = { nombre: nombre.trim().slice(0, 40), q: filters.q, owner: filters.owner, client: filters.client, state: filters.state, mode, groupBy };
      savedViews = [...savedViews.filter((item) => item.nombre !== vista.nombre), vista].slice(-8);
      try {
        await account.updatePrefs({ ...userPrefs, vistas: savedViews });
        userPrefs = { ...userPrefs, vistas: savedViews };
        notify(`Vista "${vista.nombre}" guardada.`);
        renderTeam();
      } catch (error) { notify(`No se pudo guardar la vista: ${error.message}`); }
    };
    clear.after(save);
  }
}
function activeFilterChips() {
  const chips = [];
  if (filters.client) chips.push(`<button type="button" class="chip active" data-drop="client">Cliente: ${escapeHtml(filters.client)} ✕</button>`);
  if (filters.owner) chips.push(`<button type="button" class="chip active" data-drop="owner">Responsable: ${escapeHtml(filters.owner)} ✕</button>`);
  if (filters.state) chips.push(`<button type="button" class="chip active" data-drop="state">Estado: ${escapeHtml(filters.state)} ✕</button>`);
  if (filters.q) chips.push(`<button type="button" class="chip active" data-drop="q">Buscar: ${escapeHtml(filters.q)} ✕</button>`);
  return chips.join('');
}
function syncFilterChips() {
  const host = $('#filter-chips');
  if (!host) return;
  const html = activeFilterChips();
  host.innerHTML = html;
  host.style.display = html ? 'flex' : 'none';
}
function savedViewsHtml() {
  if (!savedViews.length) return '<div class="toolbar" style="margin:-6px 0 10px"><span class="note" style="margin:0">Guarda una combinación de filtros para volver a ella con un clic.</span></div>';
  return `<div class="toolbar" style="margin:-6px 0 10px">
    <span class="note" style="margin:0">Vistas guardadas:</span>
    ${savedViews.map((view, index) => `<button class="btn" data-saved-view="${index}">${escapeHtml(view.nombre)}</button>`).join('')}
  </div>`;
}
function renderTeam() {
  const view = $('#view');
  view.innerHTML = toolbarHtml() + '<div class="toolbar" id="filter-chips" style="margin:-4px 0 10px;gap:6px"></div>' + savedViewsHtml();
  fillFilters();
  const host = document.createElement('div');
  host.id = 'team-body';
  view.appendChild(host);
  syncFilterChips();
  renderTeamBody();
}
function teamSummary(list) {
  const active = list.filter((task) => !isDone(task)).length;
  const overdue = list.filter(isOverdue).length;
  const review = list.filter((task) => task.status === 'En revisión').length;
  const week = weekRange();
  const dueWeek = list.filter((task) => task.due && task.due >= week.from && task.due <= week.to && !isDone(task)).length;
  return `<section class="cards">
    <div class="card accent"><div class="k">Tareas activas</div><div class="v">${active}</div></div>
    <div class="card"><div class="k">Vencidas</div><div class="v" style="color:${overdue ? 'var(--red)' : 'inherit'}">${overdue}</div></div>
    <div class="card"><div class="k">En revisión</div><div class="v">${review}</div></div>
    <div class="card"><div class="k">Vencen esta semana</div><div class="v">${dueWeek}</div></div>
    <div class="card"><div class="k">Total</div><div class="v">${list.length}</div></div>
  </section>`;
}
function renderTeamBody() {
  const host = $('#team-body');
  if (!host) return;
  const list = visibleRows();
  const head = attentionHtml(list) + teamSummary(list);
  if (mode === 'kanban') host.innerHTML = head + kanbanHtml(list);
  else if (mode === 'lista') host.innerHTML = head + listHtml(list);
  else host.innerHTML = head + calendarHtml(list);
  if (mode === 'kanban') restoreColumnScroll();
  syncFilterChips();
  const groupSel = $('#group-filter');
  if (groupSel) groupSel.style.display = mode === 'lista' ? '' : 'none';
}
const openGroups = new Set();
const columnScroll = new Map();

function captureColumnScroll() {
  document.querySelectorAll('.column[data-col]').forEach((column) => {
    columnScroll.set(column.dataset.col, column.scrollTop);
  });
}
function restoreColumnScroll() {
  document.querySelectorAll('.column[data-col]').forEach((column) => {
    const top = columnScroll.get(column.dataset.col);
    if (typeof top === 'number') column.scrollTop = top;
  });
}
function accordionHtml(state, tasks) {
  const byClient = new Map();
  for (const task of tasks) {
    const key = task.client || 'Sin cliente';
    if (!byClient.has(key)) byClient.set(key, []);
    byClient.get(key).push(task);
  }
  const names = [...byClient.keys()].sort((a, b) => a.localeCompare(b, 'es'));
  return names.map((name) => {
    const group = byClient.get(name).slice().sort(sortTasks);
    const late = group.filter((task) => task.overdue).length;
    const id = `${state}||${name}`;
    const open = openGroups.has(id);
    return `<section class="ag">
      <button type="button" class="aghead" data-ag="${escapeHtml(id)}" aria-expanded="${open}">
        <span class="caret">▼</span>
        <span class="agname">${escapeHtml(name)} (${group.length})</span>
        ${late ? `<span class="agwarn" title="${late} vencida${late === 1 ? '' : 's'}">⚠</span>` : ''}
      </button>
      ${open ? `<div class="agbody">${group.map(taskCard).join('')}</div>` : ''}
    </section>`;
  }).join('');
}
function kanbanHtml(list) {
  const grouped = !filters.client;
  const columns = STATES.filter((state) => state !== 'Atrasada');
  return `<div class="board">${columns.map((state) => {
    const tasks = list.filter((task) => task.status === state).sort(sortTasks);
    const body = tasks.length
      ? (grouped ? accordionHtml(state, tasks) : tasks.map(taskCard).join(''))
      : '<div class="empty">Sin tareas en esta etapa</div>';
    return `<section class="column${tasks.length ? '' : ' empty-col'}" data-col="${escapeHtml(state)}">
      <div class="colhead"><span>${escapeHtml(state)}</span><span class="count">${tasks.length}</span></div>
      <div class="colbody">${body}</div>
    </section>`;
  }).join('')}</div>`;
}
let listPage = 1;
let listPageSize = 25;
let listSort = { key: 'due', dir: 1 };
let groupBy = 'cliente';

function fmtShortDay(value) {
  return value ? `${value.slice(8, 10)}/${value.slice(5, 7)}` : '—';
}
function groupKey(task) {
  if (groupBy === 'responsable') return task.owner || 'Sin asignar';
  if (groupBy === 'estado') return task.status;
  if (groupBy === 'cliente') return task.client || 'Sin cliente';
  return 'Todas las tareas';
}
function sortListRows(list) {
  const { key, dir } = listSort;
  const val = (task) => {
    if (key === 'priority') return priorityRank(task);
    if (key === 'due') return task.due || '9999-99-99';
    if (key === 'status') return task.status;
    if (key === 'client') return task.client || 'zz';
    if (key === 'owner') return task.owner || 'zz';
    return String(task.title || '').toLowerCase();
  };
  return list.slice().sort((a, b) => {
    const x = val(a);
    const y = val(b);
    const cmp = typeof x === 'number' ? x - y : String(x).localeCompare(String(y), 'es');
    return cmp !== 0 ? cmp * dir : sortTasks(a, b);
  });
}
function listHtml(list) {
  const ordered = sortListRows(list);
  const total = ordered.length;
  const pages = Math.max(1, Math.ceil(total / listPageSize));
  if (listPage > pages) listPage = pages;
  if (listPage < 1) listPage = 1;
  const start = (listPage - 1) * listPageSize;
  let orderedGroups;
  if (groupBy) {
    const buckets = new Map();
    for (const task of sortListRows(list)) {
      const key = groupKey(task);
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(task);
    }
    const order = groupBy === 'estado' ? STATES : [...buckets.keys()].sort((a, b) => String(a).localeCompare(String(b), 'es'));
    orderedGroups = order
      .filter((key) => buckets.has(key))
      .map((key) => ({ key, tasks: buckets.get(key) }));
  } else {
    orderedGroups = [{ key: '', tasks: sortListRows(list) }];
  }
  const flat = [];
  for (const group of orderedGroups) for (const task of group.tasks) flat.push({ group: group.key, task, size: group.tasks.length });
  const slice = flat.slice(start, start + listPageSize);
  let lastGroup = slice.length && slice[0].group !== '' ? '__none__' : '';
  const arrow = (key) => (listSort.key === key ? (listSort.dir === 1 ? ' ▲' : ' ▼') : '');
  const head = `<div class="trow thead">
      <button type="button" data-sort="title">Tarea${arrow('title')}</button>
      <button type="button" class="col-client" data-sort="client">Cliente${arrow('client')}</button>
      <button type="button" class="col-owner" data-sort="owner">Responsable${arrow('owner')}</button>
      <button type="button" class="col-date" data-sort="due">Vence${arrow('due')}</button>
      <button type="button" class="col-state" data-sort="status">Estado${arrow('status')}</button>
      <button type="button" class="col-prio" data-sort="priority">Prioridad${arrow('priority')}</button>
      <span class="col-act"></span>
    </div>`;
  const body = slice.map((entry) => {
    const task = entry.task;
    let header = '';
    if (entry.group && entry.group !== lastGroup) {
      lastGroup = entry.group;
      const groupTasksList = orderedGroups.find((item) => item.key === entry.group)?.tasks || [];
      const lateCount = groupTasksList.filter((item) => item.overdue).length;
      header = `<div class="ghead"><span>${escapeHtml(entry.group)}</span><span class="note">${groupTasksList.length} ${groupTasksList.length === 1 ? 'tarea' : 'tareas'}${lateCount ? ` · <span class="late">${lateCount} vencidas</span>` : ''}</span></div>`;
    }
    if (entry.group === '') lastGroup = '';
    const done = isDone(task);
    const next = task.status === 'En proceso' ? 'done' : 'start';
    const label = task.status === 'En proceso' ? 'Finalizar' : 'Iniciar';
    return `${header}<div class="trow${task.overdue ? ' late' : ''}${done ? ' done' : ''}" data-task="${escapeHtml(task.id)}">
      <span class="cell-title"><b>${escapeHtml(task.title)}</b>${task.reprocesoCount ? `<em class="mini">reproceso ${task.reprocesoCount}</em>` : ''}</span>
      <span class="col-client ellipsis">${escapeHtml(task.client || '—')}</span>
      <span class="col-owner ellipsis">${escapeHtml(task.owner)}</span>
      <span class="col-date ${task.overdue ? 'late-txt' : ''}">${escapeHtml(fmtShortDay(task.due))}${task.overdue ? ' ⚠' : ''}</span>
      <span class="col-state">${statusPill(task.status)}</span>
      <span class="col-prio"><span class="tag ${task.priority === 'Urgente' ? 'urgent' : task.priority === 'Alta' ? 'high' : ''}">${escapeHtml(task.priority)}</span></span>
      <span class="col-act">${done ? '' : `<button type="button" class="btn mini" data-action="${next}" data-task="${escapeHtml(task.id)}">${label}</button>`}</span>
    </div>`;
  }).join('') || '<div class="empty">Sin tareas con estos filtros</div>';
  const windowed = [];
  for (let n = 1; n <= pages; n += 1) {
    if (pages <= 7 || n === 1 || n === pages || Math.abs(n - listPage) <= 1) windowed.push(n);
    else if (windowed[windowed.length - 1] !== '…') windowed.push('…');
  }
  const pager = `<div class="pager">
      <span class="note" style="margin:0">${total ? `Mostrando ${start + 1}–${Math.min(start + listPageSize, total)} de ${total}` : 'Sin resultados'}</span>
      <span class="grow"></span>
      <select id="page-size" class="filter" aria-label="Tareas por página">${[25, 50, 100].map((n) => `<option value="${n}" ${n === listPageSize ? 'selected' : ''}>${n} por página</option>`).join('')}</select>
      <button type="button" class="btn mini" data-page="${listPage - 1}" ${listPage === 1 ? 'disabled' : ''}>‹</button>
      ${windowed.map((n) => (n === '…' ? '<span class="note" style="margin:0">…</span>' : `<button type="button" class="btn mini ${n === listPage ? 'on' : ''}" data-page="${n}">${n}</button>`)).join('')}
      <button type="button" class="btn mini" data-page="${listPage + 1}" ${listPage === pages ? 'disabled' : ''}>›</button>
    </div>`;
  return `<div class="table">${head}${body}</div>${pager}`;
}
function calendarHtml(list) {
  const year = calDate.getFullYear();
  const month = calDate.getMonth();
  const first = new Date(year, month, 1);
  const offset = (first.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const byDay = new Map();
  for (const task of list) {
    if (!task.due) continue;
    if (!byDay.has(task.due)) byDay.set(task.due, []);
    byDay.get(task.due).push(task);
  }
  const cells = [];
  for (let i = 0; i < offset; i += 1) {
    const d = new Date(year, month, 1 - (offset - i));
    cells.push({ date: d, out: true });
  }
  for (let day = 1; day <= daysInMonth; day += 1) cells.push({ date: new Date(year, month, day), out: false });
  while (cells.length % 7 !== 0) {
    const last = cells[cells.length - 1].date;
    const d = new Date(last); d.setDate(last.getDate() + 1);
    cells.push({ date: d, out: true });
  }
  const today = todayIso();
  const grid = cells.map(({ date, out }) => {
    const key = isoDay(date);
    const tasks = (byDay.get(key) || []).slice().sort(sortTasks);
    const expanded = expandedDays.has(key);
    const shown = expanded ? tasks : tasks.slice(0, 2);
    const hidden = tasks.length - shown.length;
    return `<div class="day ${out ? 'out' : ''} ${key === today ? 'today' : ''}">
      <div class="num"><span>${date.getDate()}</span>${tasks.length ? `<span class="count">${tasks.length}</span>` : ''}</div>
      ${shown.map((task) => `<div class="ev" data-state="${escapeHtml(task.status)}" data-overdue="${isOverdue(task)}" data-task="${escapeHtml(task.id)}" title="${escapeHtml(task.title)}"><b>${escapeHtml(task.title.slice(0, 34))}</b><small>${escapeHtml(task.owner)}${task.status === 'Finalizada' ? ' · finalizada' : isOverdue(task) ? ' · vencida' : ''}</small></div>`).join('')}
      ${hidden > 0 ? `<button class="more" data-expand="${key}">+${hidden} más</button>` : ''}
      ${expanded && tasks.length > 2 ? `<button class="more" data-collapse="${key}">ver menos</button>` : ''}
    </div>`;
  }).join('');
  return `<div class="cal-head">
    <button class="btn" data-cal="prev">‹</button>
    <div class="cal-title">${MONTH_FMT.format(calDate)}</div>
    <button class="btn" data-cal="next">›</button>
    <button class="btn ghost" data-cal="today">Hoy</button>
    <span class="grow"></span>
    <span class="chip">${list.filter((task) => task.due).length} con fecha</span>
  </div>
  <div class="cal">${DAY_NAMES.map((name) => `<div class="dow">${name}</div>`).join('')}${grid}</div>`;
}

/* ---------------- Clientes ---------------- */

async function renderClients() {
  const view = $('#view');
  view.innerHTML = '<div class="empty">Cargando clientes…</div>';
  await Promise.all([loadClientes(), loadTemplates()]);
  const counts = new Map();
  for (const task of rows) {
    if (!task.client) continue;
    const entry = counts.get(task.client) || { total: 0, active: 0 };
    entry.total += 1;
    if (!isDone(task)) entry.active += 1;
    counts.set(task.client, entry);
  }
  const editable = ['admin', 'supervisor'].includes(currentRole);
  const memberOptions = (selected) => '<option value="">Sin asignar</option>'
    + teamMembers.map((m) => `<option value="${escapeHtml(m.id)}" ${m.id === selected ? 'selected' : ''}>${escapeHtml(m.name)}</option>`).join('');
  const templateOptions = (selected) => '<option value="">Sin plantilla</option>'
    + templates.map((t) => `<option value="${escapeHtml(t.id)}" ${t.id === selected ? 'selected' : ''}>${escapeHtml(t.nombre)}</option>`).join('');
  view.innerHTML = `
    <div class="cards">
      <div class="card accent"><div class="k">Clientes</div><div class="v">${clientes.length}</div></div>
      <div class="card"><div class="k">Con tareas activas</div><div class="v">${clientes.filter((c) => (counts.get(c.nombre)?.active || 0) > 0).length}</div></div>
      <div class="card"><div class="k">Plantillas disponibles</div><div class="v">${templates.length}</div></div>
    </div>
    <div class="list">
      <div class="row head" style="grid-template-columns:1.4fr .8fr 1fr 1fr 1fr .6fr 1.4fr">
        <span>Cliente</span><span>Frecuencia</span><span>Dueño relación</span><span>Responsable</span><span>Revisor</span><span>Día</span><span>Acciones</span>
      </div>
      ${clientes.map((c) => {
        const entry = counts.get(c.nombre) || { total: 0, active: 0 };
        return `<div class="row" style="grid-template-columns:1.4fr .8fr 1fr 1fr 1fr .6fr 1.4fr;cursor:default" data-client-row="${escapeHtml(c.id)}">
          <span><b>${escapeHtml(c.nombre)}</b><br><small style="color:var(--muted)">${entry.active} activas · ${entry.total} total</small></span>
          <span><select class="filter" data-field="frecuencia" ${editable ? '' : 'disabled'}>
            <option value="mensual" ${c.frecuencia === 'mensual' ? 'selected' : ''}>Mensual</option>
            <option value="trimestral" ${c.frecuencia === 'trimestral' ? 'selected' : ''}>Trimestral</option>
          </select></span>
          <span><select class="filter" data-field="dueno_relacion_id" ${editable ? '' : 'disabled'}>${memberOptions(c.duenoId)}</select></span>
          <span><select class="filter" data-field="responsable_ejecucion_id" ${editable ? '' : 'disabled'}>${memberOptions(c.responsableId)}</select></span>
          <span><select class="filter" data-field="revisor_id" ${editable ? '' : 'disabled'}>${memberOptions(c.revisorId)}</select></span>
          <span><input class="filter" type="number" min="1" max="28" value="${c.diaVencimiento}" data-field="dia_vencimiento" style="width:64px" ${editable ? '' : 'disabled'}></span>
          <span style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn" data-save-client="${escapeHtml(c.id)}" ${editable ? '' : 'disabled'}>Guardar</button>
            <button class="btn primary" data-generate="${escapeHtml(c.id)}" ${editable ? '' : 'disabled'}>Generar mes</button>
          </span>
          <span class="hide-s"><select class="filter" data-field="plantilla_id" ${editable ? '' : 'disabled'} style="grid-column:1/-1;margin-top:6px">${templateOptions(c.plantillaId)}</select></span>
        </div>`;
      }).join('') || '<div class="empty">Sin clientes registrados. Créalos en Appwrite o pide que los carguemos.</div>'}
    </div>
    <div class="toolbar" style="margin-top:14px">
      <label style="font-size:12px;color:var(--muted);font-weight:650">Período a generar
        <input class="filter" type="month" id="generate-period" value="${new Date().toISOString().slice(0, 7)}" style="margin-left:8px">
      </label>
      <span class="note" style="margin:0">Se usa la plantilla del cliente y su día de vencimiento. Si ya hay tareas de ese cliente en el período, se avisa y no se duplica nada.</span>
    </div>`;
}

function attentionItems(list) {
  const REVIEW_DAYS = 3;
  const WORKLOAD_FACTOR = 2;
  const alerts = [];
  const today = todayIso();
  const byOwner = new Map();
  for (const task of list) {
    if (isDone(task)) continue;
    const entry = byOwner.get(task.owner) || { overdue: 0, active: 0 };
    entry.active += 1;
    if (task.due && task.due < today) entry.overdue += 1;
    byOwner.set(task.owner, entry);
  }
  for (const [owner, entry] of byOwner) {
    if (owner !== 'Sin asignar' && entry.overdue > 0) alerts.push(`${owner} tiene ${entry.overdue} tarea${entry.overdue === 1 ? '' : 's'} vencida${entry.overdue === 1 ? '' : 's'}`);
  }
  const byClient = new Map();
  for (const task of list) {
    if (task.status !== 'En revisión') continue;
    const days = Math.floor((Date.now() - new Date(task.updatedAt || Date.now()).getTime()) / 86400000);
    if (days < REVIEW_DAYS) continue;
    const entry = byClient.get(task.client || 'Sin cliente') || { count: 0, days };
    entry.count += 1;
    entry.days = Math.max(entry.days, days);
    byClient.set(task.client || 'Sin cliente', entry);
  }
  for (const [client, entry] of byClient) {
    alerts.push(`${client}: ${entry.count} en revisión sin cambios hace ${entry.days} días`);
  }
  const active = [...byOwner.entries()].filter(([owner]) => owner !== 'Sin asignar');
  if (active.length >= 2) {
    const average = active.reduce((sum, [, entry]) => sum + entry.active, 0) / active.length;
    if (average > 0) {
      for (const [owner, entry] of active) {
        if (entry.active > average * WORKLOAD_FACTOR) alerts.push(`${owner} tiene ${entry.active} tareas activas: más del doble del promedio (${average.toFixed(1)})`);
      }
    }
  }
  return alerts;
}

function attentionHtml(list) {
  const alerts = attentionItems(list).slice(0, 5);
  if (!alerts.length) return '';
  return `<div class="card" style="border-color:#f0d9c8;background:linear-gradient(180deg,#fff9f4,#fff);margin-bottom:14px">
    <div class="k" style="color:var(--orange)">Requiere atención</div>
    <ul style="margin:8px 0 0;padding-left:18px;color:#5c5148">${alerts.map((alert) => `<li>${escapeHtml(alert)}</li>`).join('')}</ul>
  </div>`;
}

/* ---------------- detalle ---------------- */

function openDetail(taskId) {
  const task = rows.find((item) => item.id === taskId);
  if (!task) return;
  const editable = canEditTask(task);
  const allowed = editable ? STATES : [...new Set([task.status, 'En proceso', 'En revisión', 'Finalizada'])];
  const checklist = task.checklist.length
    ? task.checklist.map((item) => `<span class="chip">${item.completado ? '✓' : '○'} ${escapeHtml(item.texto)}</span>`).join('')
    : '<span class="chip">Sin checklist</span>';
  const comments = task.comments.slice(-4).map((comment) => `<div style="font-size:12px;padding:4px 0;border-bottom:1px solid #f1f3f0"><b>${escapeHtml(comment.autor_nombre || '')}</b>: ${escapeHtml(comment.texto || '')}</div>`).join('') || '<div class="empty">Sin comentarios</div>';
  $('#detail-body').innerHTML = `
    <h2>${escapeHtml(task.title)}</h2>
    <div class="detail-grid">
      <div><span>Cliente</span><b>${escapeHtml(task.client || '—')}</b></div>
      <div><span>Responsable</span><b>${escapeHtml(task.owner)}</b></div>
      <div><span>Estado</span><b>${escapeHtml(task.status)}</b></div>
      <div><span>Prioridad</span><b>${escapeHtml(task.priority)}</b></div>
      <div><span>Fecha límite</span><b>${task.due ? escapeHtml(task.due) : '—'}</b></div>
      <div><span>Inicio real</span><b>${task.startReal || '—'}</b></div>
      <div><span>Fin real</span><b>${task.endReal || '—'}</b></div>
      <div><span>Reprocesos</span><b>${task.reprocesoCount}${task.lastReproceso ? ` · ${escapeHtml(task.lastReproceso)}` : ''}</b></div>
    </div>
    ${task.description ? `<p style="color:#4b564f">${escapeHtml(task.description)}</p>` : ''}
    <h3>Checklist</h3><div class="chips">${checklist}</div>
    <h3 style="margin-top:14px">Comentarios</h3>${comments}
    <div class="form" style="margin-top:14px">
      <label>Cambiar estado<select id="detail-status" ${editable ? '' : 'disabled'}>${allowed.map((state) => `<option ${state === task.status ? 'selected' : ''}>${state}</option>`).join('')}</select></label>
      <label>Nuevo comentario<input id="detail-comment" placeholder="Escribe una nota"></label>
    </div>
    <div class="dialog-actions">
      <button class="btn" data-close="1">Cerrar</button>
      <button class="btn primary" id="detail-save" ${editable ? '' : 'disabled'}>Guardar cambios</button>
    </div>`;
  $('#detail-modal').classList.add('open');
  $('#detail-save').onclick = async () => {
    const state = $('#detail-status').value;
    const comment = $('#detail-comment').value.trim();
    try {
      if (state !== task.status) {
        await pushStatus(task, state);
      }
      if (comment) {
        await executeActivityService({ action: 'comment', activityId: task.id, text: comment });
      }
      $('#detail-modal').classList.remove('open');
      scheduleRefresh();
    } catch (error) { notify(`No se pudo guardar: ${error.message}`); }
  };
}

async function freshUpdatedAt(task) {
  try {
    const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLE_ID, rowId: task.id });
    return row.$updatedAt;
  } catch (error) { return task.updatedAt; }
}
async function pushStatus(task, estado) {
  let expected = await freshUpdatedAt(task);
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      await executeActivityService({ action: 'update', activityId: task.id, expectedUpdatedAt: expected, patch: { estado } });
      return true;
    } catch (error) {
      const conflict = /cambió desde que la abriste|Actualiza la actividad antes|409/i.test(error.message || '');
      if (!conflict || attempt === 2) throw error;
      expected = await freshUpdatedAt(task);
    }
  }
  return false;
}
async function setStatus(taskId, estado) {
  const task = rows.find((item) => item.id === taskId);
  if (!task) return;
  if (estado === 'Finalizada' && !canFinalizeActivity(task)) {
    notify('No se puede finalizar: quedan requisitos obligatorios pendientes.');
    return;
  }
  const before = { status: task.status, overdue: task.overdue };
  task.status = estado;
  task.overdue = !isDone(task) && Boolean(task.due) && task.due < todayIso();
  render();
  try {
    await pushStatus(task, estado);
    notify(`Estado actualizado: ${estado}.`);
    scheduleRefresh();
  } catch (error) {
    task.status = before.status;
    task.overdue = before.overdue;
    render();
    notify(`No se pudo cambiar el estado: ${error.message}`);
  }
}

/* ---------------- diagnostico (solo ?diag=1) ---------------- */

if (new URLSearchParams(location.search).has('diag')) {
  window.__board = {
    getFilters: () => ({ ...filters }),
    setFilter: (field, value) => { filters[field] = value; fillFilters(); renderTeamBody(); },
    setRowsForTest: (list) => { rows = list; },
    render: () => renderTeam(),
    counts: () => ({
      columnas: [...document.querySelectorAll('.column')].map((c) => ({ estado: c.dataset.col, n: c.querySelector('.count')?.textContent })),
      acordeones: [...document.querySelectorAll('.aghead .agname')].map((n) => n.textContent),
      filas: document.querySelectorAll('.trow[data-task]').length,
      vacios: [...document.querySelectorAll('.column .empty')].length,
    }),
  };
}

/* ---------------- eventos ---------------- */

document.querySelectorAll('nav.views button').forEach((button) => {
  button.addEventListener('click', () => go(button.dataset.route));
});
window.addEventListener('hashchange', render);
document.addEventListener('change', (event) => {
  if (event.target && event.target.id === 'page-size') {
    listPageSize = Number(event.target.value) || 25;
    listPage = 1;
    renderTeamBody();
  }
});
$('#team-selector').addEventListener('change', (event) => {
  if (event.target.value) loadMembers(event.target.value).then(() => loadRows()).catch((error) => notify(`No se pudieron actualizar los miembros del equipo: ${error.message}`));
});
$('#new-task').onclick = () => $('#modal').classList.add('open');
$('#cancel').onclick = () => $('#modal').classList.remove('open');
$('#modal').addEventListener('click', (event) => { if (event.target.id === 'modal') $('#modal').classList.remove('open'); });
$('#detail-modal').addEventListener('click', (event) => {
  if (event.target.id === 'detail-modal' || event.target.dataset.close) $('#detail-modal').classList.remove('open');
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') { $('#modal').classList.remove('open'); $('#detail-modal').classList.remove('open'); }
});

$('#view').addEventListener('click', async (event) => {
  const quick = event.target.closest('[data-quick]');
  if (quick) { quickFilter = quick.dataset.quick; renderMyDay(); return; }
  const action = event.target.closest('[data-action]');
  if (action) {
    event.stopPropagation();
    setStatus(action.dataset.task, action.dataset.action === 'start' ? 'En proceso' : 'Finalizada');
    return;
  }
  const expand = event.target.closest('[data-expand]');
  if (expand) { expandedDays.add(expand.dataset.expand); renderTeamBody(); return; }
  const collapse = event.target.closest('[data-collapse]');
  if (collapse) { expandedDays.delete(collapse.dataset.collapse); renderTeamBody(); return; }
  const cal = event.target.closest('[data-cal]');
  if (cal) {
    const step = cal.dataset.cal;
    if (step === 'today') calDate = startOfMonth(new Date());
    else { const d = new Date(calDate); d.setMonth(calDate.getMonth() + (step === 'next' ? 1 : -1)); calDate = startOfMonth(d); }
    renderTeamBody();
    return;
  }
  const filtersToggle = event.target.closest('#filters-toggle');
  if (filtersToggle) {
    const panel = $('#filters-panel');
    const open = panel.hasAttribute('hidden');
    if (open) panel.removeAttribute('hidden');
    else panel.setAttribute('hidden', '');
    filtersToggle.setAttribute('aria-expanded', String(open));
    return;
  }
  const dropChip = event.target.closest('[data-drop]');
  if (dropChip) {
    const field = dropChip.dataset.drop;
    filters[field] = '';
    if (field === 'q') { const search = $('#search'); if (search) search.value = ''; }
    fillFilters();
    renderTeamBody();
    return;
  }
  const agBtn = event.target.closest('[data-ag]');
  if (agBtn) {
    const id = agBtn.dataset.ag;
    captureColumnScroll();
    if (openGroups.has(id)) openGroups.delete(id);
    else openGroups.add(id);
    renderTeamBody();
    restoreColumnScroll();
    return;
  }
  const sortBtn = event.target.closest('[data-sort]');
  if (sortBtn) {
    const key = sortBtn.dataset.sort;
    listSort = { key, dir: listSort.key === key ? -listSort.dir : 1 };
    listPage = 1;
    renderTeamBody();
    return;
  }
  const pageBtn = event.target.closest('[data-page]');
  if (pageBtn) {
    const target = Number(pageBtn.dataset.page);
    if (target && target !== listPage) { listPage = target; renderTeamBody(); }
    return;
  }
  const modeButton = event.target.closest('[data-mode]');
  if (modeButton) { mode = modeButton.dataset.mode; document.querySelectorAll('.seg [data-mode]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.mode === mode))); renderTeamBody(); return; }
  const taskEl = event.target.closest('[data-task]');
  if (taskEl) { openDetail(taskEl.dataset.task); return; }
  const savedViewBtn = event.target.closest('[data-saved-view]');
  if (savedViewBtn) {
    const view = savedViews[Number(savedViewBtn.dataset.savedView)];
    if (view) {
      filters.q = view.q || '';
      filters.owner = view.owner || '';
      filters.client = view.client || '';
      filters.state = view.state || '';
      if (view.mode) mode = view.mode;
      if (typeof view.groupBy === 'string') groupBy = view.groupBy;
      const search = $('#search'); if (search) search.value = filters.q;
      fillFilters();
      renderTeamBody();
    }
    return;
  }
  const saveBtn = event.target.closest('[data-save-client]');
  if (saveBtn) {
    const rowEl = saveBtn.closest('[data-client-row]');
    const data = {};
    rowEl.querySelectorAll('[data-field]').forEach((field) => {
      data[field.dataset.field] = field.type === 'number' ? Number(field.value) : field.value;
    });
    try {
      await executeActivityService({ action: 'client.update', clientId: saveBtn.dataset.saveClient, data });
      notify('Cliente actualizado.');
      clientes = [];
      await renderClients();
    } catch (error) { notify(`No se pudo guardar el cliente: ${error.message}`); }
    return;
  }
  const genBtn = event.target.closest('[data-generate]');
  if (genBtn) {
    const periodo = $('#generate-period')?.value || new Date().toISOString().slice(0, 7);
    const name = genBtn.closest('[data-client-row]')?.querySelector('b')?.textContent || 'el cliente';
    if (!confirm(`¿Generar las tareas de ${name} para el período ${periodo}?`)) return;
    try {
      const result = await executeActivityService({ action: 'generate', clientId: genBtn.dataset.generate, periodo });
      if (result.conflict) notify(`Ya existen ${result.existentes} tareas de ${name} en ${periodo}. No se generó nada.`);
      else { notify(`Se generaron ${result.creadas} tareas de ${name} para ${periodo}.`); scheduleRefresh(); }
    } catch (error) { notify(`No se pudo generar: ${error.message}`); }
    return;
  }
  const clientEl = event.target.closest('[data-client]');
  if (clientEl) { filters.client = clientEl.dataset.client; go('equipo'); }
});
document.addEventListener('click', (event) => {
  const panel = $('#filters-panel');
  if (!panel || panel.hasAttribute('hidden')) return;
  if (event.target.closest('#filters-toggle') || event.target.closest('#filters-panel')) return;
  panel.setAttribute('hidden', '');
  const toggle = $('#filters-toggle');
  if (toggle) toggle.setAttribute('aria-expanded', 'false');
});
$('#view').addEventListener('change', (event) => {
  const target = event.target;
  if (target.id === 'owner-filter') { filters.owner = target.value; renderTeamBody(); }
  else if (target.id === 'client-filter') { filters.client = target.value; renderTeamBody(); }
  else if (target.id === 'state-filter') { filters.state = target.value; renderTeamBody(); }
});
$('#view').addEventListener('input', (event) => {
  if (event.target.id === 'search') { filters.q = event.target.value; renderTeamBody(); }
});
$('#view').addEventListener('click', (event) => {
  if (event.target.id === 'clear-filters') {
    filters.q = ''; filters.owner = ''; filters.client = ''; filters.state = '';
    const search = $('#search'); if (search) search.value = '';
    fillFilters(); renderTeamBody();
  }
});

$('#task-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!['admin', 'supervisor'].includes(currentRole)) { notify('Solo administración o supervisión puede crear actividades.'); return; }
  const data = new FormData(event.currentTarget);
  try {
    const priority = String(data.get('priority') || 'Media');
    if (!ACTIVITY_PRIORITIES.includes(priority)) throw new Error('Selecciona una prioridad válida.');
    const activity = {
      titulo: String(data.get('title') || '').trim(),
      cliente: String(data.get('client') || '').trim(),
      responsable_id: String(data.get('owner') || ''),
      colaboradores_ids: data.getAll('collaborators').map(String),
      fecha_limite: new Date(`${data.get('due')}T12:00:00.000Z`).toISOString(),
      estado: String(data.get('status') || 'Asignada'),
      prioridad: priority,
      descripcion: String(data.get('description') || '').trim(),
      departamento: String(data.get('department') || '').trim(),
      categoria: String(data.get('category') || '').trim(),
      checklist: checklistFromLines(data.get('checklist')),
    };
    const start = String(data.get('start') || '');
    if (start) activity.fecha_inicio = new Date(`${start}T12:00:00.000Z`).toISOString();
    await executeActivityService({ action: 'create', activity });
    event.currentTarget.reset();
    $('#modal').classList.remove('open');
    scheduleRefresh();
  } catch (error) { notify(`No se pudo crear la tarea: ${error.message}`); }
});

/* ---------------- arranque ---------------- */

function showLogin(error) {
  let box = $('#login-panel');
  if (box) {
    box.querySelector('.login-error').textContent = error?.message || 'Inicia sesión con una cuenta del equipo para continuar.';
    return;
  }
  box = document.createElement('div');
  box.id = 'login-panel';
  box.style.cssText = 'position:fixed;inset:0;background:#f7f8f5;display:grid;place-items:center;z-index:1000;padding:20px';
  box.innerHTML = `<form style="width:min(380px,100%);background:white;border:1px solid #e7ebe6;border-radius:14px;padding:24px"><h2>Ingresar al tablero</h2><p>Usa tu cuenta de equipo.</p><label style="display:grid;gap:6px;margin:12px 0">Correo<input name="email" type="email" required autocomplete="username" style="padding:10px"></label><label style="display:grid;gap:6px;margin:12px 0">Contraseña<input name="password" type="password" required autocomplete="current-password" style="padding:10px"></label><p class="login-error" role="alert"></p><button class="btn primary" style="width:100%">Iniciar sesión</button><button type="button" class="retry" style="width:100%;margin-top:8px;background:none;border:0;color:#197451;font-weight:700;cursor:pointer">Reintentar conexión</button></form>`;
  document.body.append(box);
  box.querySelector('.retry').onclick = () => location.reload();
  box.querySelector('.login-error').textContent = error?.message || 'Inicia sesión con una cuenta del equipo para continuar.';
  box.querySelector('form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const button = event.currentTarget.querySelector('button');
    button.disabled = true;
    try {
      await account.createEmailPasswordSession({ email: form.get('email'), password: form.get('password') });
      box.remove(); await startBoard();
    } catch (loginError) {
      box.querySelector('.login-error').textContent = loginError.message || 'No se pudo iniciar sesión.';
      button.disabled = false;
    }
  });
}

async function startBoard() {
  let user;
  setSyncStatus('Conectando…', 'syncing');
  try {
    user = await withTimeout(account.get(), 12000, 'Conectar con Appwrite');
  } catch (error) {
    const message = /tardó más/.test(error.message || '') ? error.message : (error.message || 'Sin sesión');
    setSyncStatus('Sin conexión', 'error');
    showLogin({ message: `${message} — pulsa Reintentar si el problema continúa.` });
    return;
  }
  currentUserId = user.$id;
  userPrefs = user.prefs || {};
  savedViews = Array.isArray(userPrefs.vistas) ? userPrefs.vistas : [];
  currentUserLabel = user.name || user.email || '';
  const avatar = $('.avatar');
  if (avatar) avatar.textContent = (currentUserLabel || 'EC').slice(0, 2).toUpperCase();
  let logout = $('#logout');
  if (!logout) {
    logout = document.createElement('button');
    logout.id = 'logout'; logout.className = 'btn'; logout.textContent = 'Cerrar sesión';
    $('.top-actions').prepend(logout);
  }
  logout.onclick = async () => { await account.deleteSession({ sessionId: 'current' }); location.reload(); };

  setSyncStatus('Cargando tareas…', 'syncing');
  try {
    await withTimeout(loadMembers(), 15000, 'Cargar el equipo');
  } catch (error) {
    notify(`No se pudieron cargar los miembros del equipo: ${error.message}`);
  }
  try {
    await withTimeout(loadRows(), 20000, 'Cargar las tareas');
  } catch (error) {
    setSyncStatus('Error de carga', 'error');
    notify(`No se pudieron cargar las tareas: ${error.message}`);
    return;
  }
  render();
  setSyncStatus('En vivo', 'connected');
  startRealtime();
}

function startRealtime() {
  if (subscription) return;
  const tasksChannel = Channel.tablesdb(DATABASE_ID).table(TABLE_ID).row();
  realtime.subscribe(tasksChannel, () => scheduleRefresh())
    .then((channel) => { subscription = channel; setSyncStatus('En vivo', 'connected'); })
    .catch((error) => { setSyncStatus('Sin tiempo real', 'error'); notify(`Sincronización en vivo no disponible: ${error.message}`); });
  realtime.subscribe(Channel.tablesdb(DATABASE_ID).table(COMMENTS_TABLE_ID).row(), () => scheduleRefresh())
    .then((channel) => { commentsSubscription = channel; })
    .catch(() => {});
  if (!membershipSubscription) {
    realtime.subscribe(Channel.memberships(), (event) => {
      if (!event.payload?.teamId || event.payload.teamId === activeTeamId) {
        loadMembers().catch((error) => notify(`No se pudieron actualizar los miembros: ${error.message}`));
      }
    }).then((channel) => { membershipSubscription = channel; }).catch(() => {});
  }
}
startBoard();
