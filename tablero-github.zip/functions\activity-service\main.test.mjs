import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler } from './main.mjs';

const base = 'https://example.invalid/v1';
const env = {
  APPWRITE_FUNCTION_API_ENDPOINT: base,
  APPWRITE_FUNCTION_PROJECT_ID: 'project-1',
  TEAM_ID: 'team-1',
  DATABASE_ID: 'database-1',
  TASKS_TABLE_ID: 'tasks',
  COMMENTS_TABLE_ID: 'activity_comments',
  HISTORY_TABLE_ID: 'activity_history',
  LOCKS_TABLE_ID: 'activity_locks',
};
const activity = {
  $id: 'task-1',
  $updatedAt: '2026-11-20T10:00:00.000Z',
  titulo: 'Preparar F29',
  responsable: 'Trabajadora Uno',
  responsable_id: 'user-1',
  colaboradores_ids: '[]',
  estado: 'Asignada',
  prioridad: 'Media',
  checklist: '[]',
};

function reply(payload, status = 200) {
  return { ok: status >= 200 && status < 300, status, json: async () => payload, text: async () => JSON.stringify(payload) };
}
function responseCapture() {
  return { json: (payload, status = 200) => ({ payload, status }), text: (payload, status = 200) => ({ payload, status }) };
}
function request(body, headers = {}) {
  return {
    req: {
      method: 'POST',
      path: '/',
      bodyJson: body,
      headers: { 'x-appwrite-trigger': 'http', 'x-appwrite-key': 'ephemeral-test-key', ...headers },
    },
    res: responseCapture(),
    log() {},
    error() {},
  };
}
function authFetch({ writes = [] } = {}) {
  let lockCreated = false;
  let task = structuredClone(activity);
  return async (input, options = {}) => {
    const url = new URL(input);
    const method = options.method || 'GET';
    if (url.pathname === '/v1/account') return reply({ $id: 'user-1', name: 'Trabajadora Uno' });
    if (url.pathname === '/v1/teams/team-1/memberships') {
      return reply({ memberships: [{ userId: 'user-1', userName: 'Trabajadora Uno', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['worker'] }] });
    }
    if (url.pathname === '/v1/tablesdb/database-1/tables/tasks/rows/task-1' && method === 'GET') return reply(task);
    if (url.pathname === '/v1/tablesdb/database-1/tables/tasks/rows/task-1' && method === 'PATCH') {
      const body = JSON.parse(options.body);
      task = { ...task, ...body.data, $updatedAt: '2026-11-20T10:01:00.000Z' };
      writes.push({ path: url.pathname, method, body });
      return reply(task);
    }
    if (url.pathname === '/v1/tablesdb/database-1/tables/activity_locks/rows/task-1' && method === 'GET') {
      return lockCreated ? reply({ $id: 'task-1', execution_id: 'exec-1', expires_at: '2026-11-20T10:02:00.000Z' }) : reply({ message: 'missing' }, 404);
    }
    if (url.pathname === '/v1/tablesdb/database-1/tables/activity_locks/rows' && method === 'POST') {
      lockCreated = true;
      writes.push({ path: url.pathname, method, body: JSON.parse(options.body) });
      return reply({ $id: 'task-1', execution_id: 'exec-1', expires_at: '2026-11-20T10:02:00.000Z' });
    }
    if (url.pathname === '/v1/tablesdb/database-1/tables/activity_locks/rows/task-1' && method === 'DELETE') {
      lockCreated = false;
      writes.push({ path: url.pathname, method });
      return reply({}, 204);
    }
    if (url.pathname === '/v1/tablesdb/database-1/tables/activity_history/rows' && method === 'POST') {
      writes.push({ path: url.pathname, method, body: JSON.parse(options.body) });
      return reply({ $id: 'history-1', ...JSON.parse(options.body) });
    }
    throw new Error(`Unexpected request: ${method} ${url.pathname}`);
  };
}

test('unauthenticated execution is rejected before touching Appwrite data', async () => {
  let calls = 0;
  const handler = createHandler({ env, fetchImpl: async () => { calls += 1; return reply({}); } });
  const result = await handler(request({ action: 'update', activityId: 'task-1', patch: { estado: 'En proceso' } }));
  assert.equal(result.status, 401);
  assert.equal(calls, 0);
});

test('assigned worker update is persisted and written to immutable history', async () => {
  const writes = [];
  const handler = createHandler({ env, fetchImpl: authFetch({ writes }), clock: () => new Date('2026-11-20T10:01:00.000Z'), id: () => 'exec-1' });
  const result = await handler(request(
    { action: 'update', activityId: 'task-1', expectedUpdatedAt: activity.$updatedAt, patch: { estado: 'En proceso' } },
    { 'x-appwrite-user-jwt': 'verified-session-jwt' },
  ));
  assert.equal(result.status, 200);
  assert.equal(result.payload.activity.estado, 'En proceso');
  assert.ok(writes.some((write) => write.path.endsWith('/tables/tasks/rows/task-1') && write.method === 'PATCH'));
  assert.ok(writes.some((write) => write.path.endsWith('/tables/activity_history/rows') && write.body.data.accion === 'updated'));
});

test('worker cannot change task priority through the service', async () => {
  const writes = [];
  const handler = createHandler({ env, fetchImpl: authFetch({ writes }), id: () => 'exec-2' });
  const result = await handler(request(
    { action: 'update', activityId: 'task-1', expectedUpdatedAt: activity.$updatedAt, patch: { prioridad: 'Urgente' } },
    { 'x-appwrite-user-jwt': 'verified-session-jwt' },
  ));
  assert.equal(result.status, 403);
  assert.equal(writes.length, 0);
});

test('admin creation grants team-level read and keeps immutable creator fields', async () => {
  const writes = [];
  const members = [
    { userId: 'admin-1', userName: 'Admin', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['admin'] },
    { userId: 'worker-1', userName: 'Trabajadora Uno', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['worker'] },
    { userId: 'worker-2', userName: 'Trabajador Dos', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['worker'] },
  ];
  const fetchImpl = async (input, options = {}) => {
    const url = new URL(input);
    if (url.pathname === '/v1/account') return reply({ $id: 'admin-1', name: 'Admin' });
    if (url.pathname === '/v1/teams/team-1/memberships') return reply({ memberships: members });
    const body = JSON.parse(options.body || '{}');
    writes.push({ path: url.pathname, method: options.method, body });
    return reply({ $id: body.rowId || 'history-1', ...body });
  };
  let nextId = 0;
  const handler = createHandler({ env, fetchImpl, id: () => `new-id-${++nextId}` });
  const result = await handler(request(
    { action: 'create', activity: {
      titulo: 'Preparar F29', cliente: 'Cliente A', responsable_id: 'worker-1',
      colaboradores_ids: ['worker-2'], fecha_limite: '2026-12-20T12:00:00.000Z',
      estado: 'Asignada', prioridad: 'Alta', checklist: [],
    } },
    { 'x-appwrite-user-jwt': 'verified-admin-jwt' },
  ));
  assert.equal(result.status, 200);
  const taskWrite = writes.find((write) => write.path.endsWith('/tables/tasks/rows'));
  assert.equal(taskWrite.body.data.creado_por_id, 'admin-1');
  assert.equal(taskWrite.body.data.modificado_por_id, 'admin-1');
  assert.equal(taskWrite.body.data.responsable, 'Trabajadora Uno');
  assert.equal(taskWrite.body.data.colaboradores_ids, '["worker-2"]');
  assert.deepEqual(taskWrite.body.permissions, ['read("team:team-1")']);
  assert.ok(writes.some((write) => write.path.endsWith('/tables/activity_history/rows')));
});

test('update requires a version token to prevent lost concurrent edits', async () => {
  const writes = [];
  const handler = createHandler({ env, fetchImpl: authFetch({ writes }), id: () => 'exec-3' });
  const result = await handler(request(
    { action: 'update', activityId: 'task-1', patch: { estado: 'En proceso' } },
    { 'x-appwrite-user-jwt': 'verified-session-jwt' },
  ));
  assert.equal(result.status, 428);
  assert.equal(writes.length, 0);
});

test('admin cannot create an already-finalized activity with required checklist items pending', async () => {
  const writes = [];
  const fetchImpl = async (input) => {
    const url = new URL(input);
    if (url.pathname === '/v1/account') return reply({ $id: 'admin-1', name: 'Admin' });
    if (url.pathname === '/v1/teams/team-1/memberships') {
      return reply({ memberships: [{ userId: 'admin-1', userName: 'Admin', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['admin'] }] });
    }
    writes.push(url.pathname);
    return reply({});
  };
  const handler = createHandler({ env, fetchImpl });
  const result = await handler(request(
    { action: 'create', activity: {
      titulo: 'Preparar F29',
      fecha_limite: '2026-12-20T12:00:00.000Z',
      estado: 'Finalizada',
      prioridad: 'Media',
      checklist: [{ texto: 'Revisar respaldo', obligatorio: true, completado: false }],
    } },
    { 'x-appwrite-user-jwt': 'verified-admin-jwt' },
  ));
  assert.equal(result.status, 409);
  assert.equal(writes.length, 0);
});

test('state changes stamp real dates, on-time closure and reproceso counters', async () => {
  const patches = [];
  const members = [{ userId: 'admin-1', userName: 'Admin', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['admin'] }];
  let task = {
    $id: 'task-1', $updatedAt: 'u0', titulo: 'Cierre mensual', responsable: 'Admin',
    responsable_id: 'admin-1', colaboradores_ids: '[]', estado: 'Asignada',
    prioridad: 'Media', checklist: '[]', fecha_limite: '2026-12-20T12:00:00.000Z', reproceso_count: 0,
  };
  const fetchImpl = async (input, options = {}) => {
    const url = new URL(input);
    const method = options.method || 'GET';
    if (url.pathname === '/v1/account') return reply({ $id: 'admin-1', name: 'Admin' });
    if (url.pathname === '/v1/teams/team-1/memberships') return reply({ memberships: members });
    if (url.pathname.includes('activity_locks') && method === 'GET') return reply({ message: 'not found' }, 404);
    if (url.pathname.includes('activity_locks')) return reply({ $id: 'lock-1' });
    if (url.pathname.endsWith('/tables/tasks/rows/task-1') && method === 'GET') return reply(task);
    if (url.pathname.endsWith('/tables/tasks/rows/task-1') && method === 'PATCH') {
      const body = JSON.parse(options.body);
      patches.push(body.data);
      task = { ...task, ...body.data };
      return reply(task);
    }
    const body = JSON.parse(options.body || '{}');
    return reply({ $id: 'created-1', ...body });
  };
  const handler = createHandler({ env, fetchImpl, clock: () => new Date('2026-12-05T10:00:00.000Z'), id: () => 'exec-1' });
  const send = (patch) => handler(request({ action: 'update', activityId: 'task-1', expectedUpdatedAt: task.$updatedAt, patch }, { 'x-appwrite-user-jwt': 'jwt' }));

  await send({ estado: 'En proceso' });
  assert.equal(patches.at(-1).fecha_inicio_real, '2026-12-05T10:00:00.000Z');

  await send({ estado: 'En revisión' });
  await send({ estado: 'En proceso' });
  assert.equal(patches.at(-1).reproceso_count, 1);
  assert.equal(patches.at(-1).ultimo_reproceso_tipo, 'En revisión → En proceso');

  await send({ estado: 'Finalizada' });
  const closed = patches.at(-1);
  assert.equal(closed.fecha_fin_real, '2026-12-05T10:00:00.000Z');
  assert.equal(closed.cerrada_a_tiempo, true);
});

function generationFetch({ total = 0 } = {}) {
  const writes = [];
  const members = [{ userId: 'admin-1', userName: 'Admin', teamId: 'team-1', joined: '2026-01-01T00:00:00Z', roles: ['admin'] }];
  const fetchImpl = async (input, options = {}) => {
    const url = new URL(input);
    const method = options.method || 'GET';
    if (url.pathname === '/v1/account') return reply({ $id: 'admin-1', name: 'Admin' });
    if (url.pathname === '/v1/teams/team-1/memberships') return reply({ memberships: members });
    if (url.pathname.endsWith('/tables/clientes/rows/client-1') && method === 'GET') {
      return reply({ $id: 'client-1', nombre: 'DENTIMAGEN', plantilla_id: 'tpl-1', dia_vencimiento: 15, responsable_ejecucion_id: 'admin-1', revisor_id: 'admin-1', frecuencia: 'mensual' });
    }
    if (url.pathname.endsWith('/tables/checklist_plantillas/rows/tpl-1') && method === 'GET') {
      return reply({ $id: 'tpl-1', nombre: 'Cierre', items: JSON.stringify([{ texto: 'Conciliar cuentas' }, { texto: 'Generar reportes' }]) });
    }
    if (url.pathname.endsWith('/tables/tasks/rows') && method === 'GET') return reply({ total, rows: [] });
    const body = JSON.parse(options.body || '{}');
    writes.push({ path: url.pathname, body });
    return reply({ $id: `new-${writes.length}`, ...body });
  };
  return { fetchImpl, writes };
}

test('generate refuses to duplicate an existing month', async () => {
  const { fetchImpl, writes } = generationFetch({ total: 3 });
  const handler = createHandler({ env, fetchImpl, id: () => 'exec-9' });
  const result = await handler(request({ action: 'generate', clientId: 'client-1', periodo: '2026-12' }, { 'x-appwrite-user-jwt': 'jwt' }));
  assert.equal(result.status, 200);
  assert.equal(result.payload.conflict, true);
  assert.equal(result.payload.existentes, 3);
  assert.equal(result.payload.creadas, 0);
  assert.equal(writes.filter((write) => write.path.endsWith('/tables/tasks/rows')).length, 0);
});

test('generate creates one task per template item and records history', async () => {
  const { fetchImpl, writes } = generationFetch({ total: 0 });
  const handler = createHandler({ env, fetchImpl, id: () => 'exec-10' });
  const result = await handler(request({ action: 'generate', clientId: 'client-1', periodo: '2026-12' }, { 'x-appwrite-user-jwt': 'jwt' }));
  assert.equal(result.status, 200);
  assert.equal(result.payload.creadas, 2);
  const taskWrites = writes.filter((write) => write.path.endsWith('/tables/tasks/rows'));
  assert.equal(taskWrites.length, 2);
  assert.equal(taskWrites[0].body.data.periodo, '2026-12');
  assert.equal(taskWrites[0].body.data.cliente_id, 'client-1');
  assert.equal(taskWrites[0].body.data.responsable_id, 'admin-1');
  assert.equal(taskWrites[0].body.data.fecha_limite, '2026-12-15T12:00:00.000Z');
  assert.deepEqual(taskWrites[0].body.permissions, ['read("team:team-1")']);
  const history = writes.filter((write) => write.path.endsWith('/tables/activity_history/rows'));
  assert.equal(history.length, 2);
  assert.equal(history[0].body.data.accion, 'generated');
});
