import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ACTIVITY_STATES,
  canFinalizeActivity,
  normalizeActivityPriority,
  normalizeActivityStatus,
  statusForActivity,
} from './workflow.mjs';

test('defines exactly the eight requested activity states', () => {
  assert.deepEqual(ACTIVITY_STATES, [
    'Pendiente', 'Asignada', 'En proceso', 'En revisión',
    'Observada', 'Finalizada', 'Cancelada', 'Atrasada',
  ]);
});

test('maps existing task statuses without discarding legacy rows', () => {
  assert.equal(normalizeActivityStatus('En curso'), 'En proceso');
  assert.equal(normalizeActivityStatus('Completada'), 'Finalizada');
  assert.equal(normalizeActivityStatus('Bloqueada'), 'Observada');
});

test('maps the former Normal priority to the new Media level', () => {
  assert.equal(normalizeActivityPriority('Normal'), 'Media');
  assert.equal(normalizeActivityPriority('Urgente'), 'Urgente');
});

test('marks overdue work late but leaves finalized and canceled work unchanged', () => {
  assert.equal(statusForActivity({ status: 'En proceso', due: '2026-11-19' }, '2026-11-20'), 'Atrasada');
  assert.equal(statusForActivity({ status: 'Finalizada', due: '2026-11-19' }, '2026-11-20'), 'Finalizada');
  assert.equal(statusForActivity({ status: 'Cancelada', due: '2026-11-19' }, '2026-11-20'), 'Cancelada');
  assert.equal(statusForActivity({ status: 'Pendiente', due: '2026-11-21' }, '2026-11-20'), 'Pendiente');
});

test('blocks finalization when a required checklist item is incomplete', () => {
  assert.equal(canFinalizeActivity({ checklist: [{ required: true, completed: false }] }), false);
  assert.equal(canFinalizeActivity({ checklist: [{ required: false, completed: false }] }), true);
  assert.equal(canFinalizeActivity({ checklist: [{ required: true, completed: true }] }), true);
});
