import {
  authorizeMutation,
  buildChangeSet,
  DomainError,
} from './domain.mjs';

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

function rowData(row) {
  return row?.data && typeof row.data === 'object' ? { ...row.data, ...Object.fromEntries(Object.entries(row).filter(([key]) => key.startsWith('$'))) } : row;
}

function parseArray(value) {
  if (Array.isArray(value)) return value;
  try { const parsed = JSON.parse(value || '[]'); return Array.isArray(parsed) ? parsed : []; }
  catch { return []; }
}

function readPermissions(activity, teamId) {
  return [`read("team:${teamId}")`];
}

function historyPermissions(teamId) {
  return [`read("team:${teamId}/admin")`, `read("team:${teamId}/supervisor")`];
}

const REPROCESO_ORIGINS = new Set(['En revisión', 'Observada', 'Finalizada']);
const ACTIVE_STATES = new Set(['Pendiente', 'Asignada', 'En proceso', 'En revisión', 'Observada']);

function stampRealDates(data, current, nextState, nowIso) {
  if (!nextState) return;
  const prevState = String(current?.estado || '');
  if (nextState === 'En proceso' && !current?.fecha_inicio_real) data.fecha_inicio_real = nowIso;
  if (nextState === 'Finalizada') {
    data.fecha_inicio_real = current?.fecha_inicio_real || nowIso;
    data.fecha_fin_real = nowIso;
    const due = Date.parse(current?.fecha_limite || '');
    data.cerrada_a_tiempo = Number.isFinite(due) ? Date.parse(nowIso) <= due : false;
  } else if (prevState === 'Finalizada') {
    data.fecha_fin_real = null;
    data.cerrada_a_tiempo = false;
  }
  if (nextState !== prevState && REPROCESO_ORIGINS.has(prevState) && ACTIVE_STATES.has(nextState)) {
    data.reproceso_count = Number(current?.reproceso_count || 0) + 1;
    data.ultimo_reproceso_tipo = `${prevState} → ${nextState}`;
  }
}

export function createHandler({ env = process.env, fetchImpl = fetch, clock = () => new Date(), id = () => crypto.randomUUID() } = {}) {
  const endpoint = String(env.APPWRITE_FUNCTION_API_ENDPOINT || '').replace(/\/$/, '');
  const projectId = env.APPWRITE_FUNCTION_PROJECT_ID || '';
  const teamId = env.TEAM_ID || '';
  const databaseId = env.DATABASE_ID || '';
  const tasksTableId = env.TASKS_TABLE_ID || '';
  const commentsTableId = env.COMMENTS_TABLE_ID || '';
  const historyTableId = env.HISTORY_TABLE_ID || '';
  const locksTableId = env.LOCKS_TABLE_ID || '';

  function pathFor(tableId, suffix = '') {
    return `/tablesdb/${encodeURIComponent(databaseId)}/tables/${encodeURIComponent(tableId)}/rows${suffix}`;
  }

  async function call(req, path, { method = 'GET', body, jwt } = {}) {
    const headers = { 'X-Appwrite-Project': projectId };
    if (jwt) headers['X-Appwrite-JWT'] = jwt;
    else if (req.headers['x-appwrite-key']) headers['X-Appwrite-Key'] = req.headers['x-appwrite-key'];
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const response = await fetchImpl(`${endpoint}${path}`, {
      method,
      headers,
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    });
    let payload = null;
    try { payload = await response.json(); } catch { /* empty body */ }
    if (!response.ok) throw new ApiError(payload?.message || 'Appwrite request failed.', response.status);
    return payload;
  }

  async function authenticate(req) {
    const jwt = req.headers['x-appwrite-user-jwt'];
    if (!jwt) throw new DomainError('Inicia sesión para continuar.', 401);
    if (!endpoint || !projectId || !teamId || !req.headers['x-appwrite-key']) {
      throw new DomainError('El servicio no tiene configuración segura completa.', 503);
    }
    let account;
    try { account = await call(req, '/account', { jwt }); }
    catch (error) { throw new DomainError('La sesión no es válida o expiró.', 401); }
    const membershipsQuery = new URLSearchParams();
    membershipsQuery.append('queries[]', JSON.stringify({ method: 'limit', values: [100] }));
    const response = await call(req, `/teams/${encodeURIComponent(teamId)}/memberships?${membershipsQuery}`);
    const membership = (response.memberships || []).find((item) => item.userId === account.$id && item.teamId === teamId && item.joined);
    if (!membership) throw new DomainError('La cuenta no pertenece al equipo autorizado.', 403);
    const role = membership.roles?.includes('admin') ? 'admin'
      : membership.roles?.includes('supervisor') ? 'supervisor'
      : membership.roles?.includes('worker') ? 'worker' : null;
    if (!role) throw new DomainError('La cuenta no tiene un rol operativo habilitado.', 403);
    return { actor: { id: account.$id, name: account.name || membership.userName || '' }, role, members: response.memberships || [] };
  }

  async function getRow(req, tableId, rowId) {
    const row = await call(req, pathFor(tableId, `/${encodeURIComponent(rowId)}`));
    return rowData(row);
  }

  async function maybeGetRow(req, tableId, rowId) {
    try { return await getRow(req, tableId, rowId); }
    catch (error) { if (error.status === 404) return null; throw error; }
  }

  async function createRow(req, tableId, data, permissions = []) {
    return call(req, pathFor(tableId), {
      method: 'POST',
      body: { rowId: id(), data, permissions },
    });
  }

  async function writeHistory(req, { activityId, actor, action, changes, activity }) {
    const data = {
      actividad_id: activityId,
      actor_id: actor.id,
      actor_nombre: actor.name,
      accion: action,
      cambios: JSON.stringify(changes),
      fecha: clock().toISOString(),
    };
    return createRow(req, historyTableId, data, historyPermissions(teamId));
  }

  async function acquireLock(req, activityId, executionId) {
    const existing = await maybeGetRow(req, locksTableId, activityId);
    if (existing) {
      const expires = Date.parse(existing.expires_at || '');
      if (!Number.isFinite(expires) || expires > clock().getTime()) {
        throw new DomainError('Otra persona está actualizando esta actividad. Actualiza y vuelve a intentar.', 409);
      }
      try { await call(req, pathFor(locksTableId, `/${encodeURIComponent(activityId)}`), { method: 'DELETE' }); }
      catch (error) { if (error.status !== 404) throw error; }
    }
    await call(req, pathFor(locksTableId), {
      method: 'POST',
      body: {
        rowId: activityId,
        data: { execution_id: executionId, expires_at: new Date(clock().getTime() + 60000).toISOString() },
        permissions: [],
      },
    });
  }

  async function releaseLock(req, activityId, executionId) {
    const current = await maybeGetRow(req, locksTableId, activityId);
    if (current?.execution_id === executionId) {
      await call(req, pathFor(locksTableId, `/${encodeURIComponent(activityId)}`), { method: 'DELETE' });
    }
  }

  async function createActivity(req, payload, auth) {
    const input = payload.activity || payload.patch || {};
    authorizeMutation({ role: auth.role, actor: auth.actor, action: 'create', patch: input });
    const responsibleId = String(input.responsable_id || '');
    const collaboratorIds = [...new Set(parseArray(input.colaboradores_ids).filter((id) => id && id !== responsibleId))];
    const participantSet = [responsibleId, ...collaboratorIds].filter(Boolean);
    if (participantSet.some((userId) => !auth.members.some((member) => member.userId === userId && member.joined))) {
      throw new DomainError('Responsable o colaborador no pertenece al equipo activo.', 400);
    }
    const responsible = auth.members.find((member) => member.userId === responsibleId);
    const data = {
      titulo: String(input.titulo).trim(),
      cliente: String(input.cliente || '').trim(),
      responsable: responsible?.userName || 'Sin asignar',
      responsable_id: responsibleId,
      colaboradores_ids: JSON.stringify(collaboratorIds),
      fecha_limite: input.fecha_limite,
      estado: input.estado || 'Pendiente',
      prioridad: input.prioridad || 'Media',
      descripcion: String(input.descripcion || ''),
      departamento: String(input.departamento || ''),
      categoria: String(input.categoria || ''),
      checklist: JSON.stringify(parseArray(input.checklist)),
      comentarios: '[]',
      creado_por_id: auth.actor.id,
      modificado_por_id: auth.actor.id,
    };
    if (input.fecha_inicio) data.fecha_inicio = input.fecha_inicio;
    stampRealDates(data, { estado: '', fecha_limite: data.fecha_limite, reproceso_count: 0 }, data.estado, clock().toISOString());
    const created = await createRow(req, tasksTableId, data, readPermissions(data, teamId));
    const activityId = created.$id || created.rowId;
    await writeHistory(req, {
      activityId,
      actor: auth.actor,
      action: 'created',
      changes: buildChangeSet({}, data),
      activity: data,
    });
    return { ok: true, activity: rowData(created) };
  }

  async function updateActivity(req, payload, auth) {
    const activityId = String(payload.activityId || '');
    if (!activityId) throw new DomainError('Falta el identificador de la actividad.');
    if (typeof payload.expectedUpdatedAt !== 'string' || !payload.expectedUpdatedAt) {
      throw new DomainError('Actualiza la actividad antes de guardar para evitar sobrescribir cambios recientes.', 428);
    }
    const initial = await getRow(req, tasksTableId, activityId);
    authorizeMutation({ role: auth.role, actor: auth.actor, action: 'update', activity: initial, patch: payload.patch || {} });
    const executionId = id();
    await acquireLock(req, activityId, executionId);
    try {
      const current = await getRow(req, tasksTableId, activityId);
      if (payload.expectedUpdatedAt && payload.expectedUpdatedAt !== current.$updatedAt) {
        throw new DomainError('La actividad cambió desde que la abriste. Actualiza antes de guardar.', 409);
      }
      const patch = payload.patch || {};
      authorizeMutation({ role: auth.role, actor: auth.actor, action: 'update', activity: current, patch });
      const beforeData = rowData(current);
      const data = { ...patch };
      let permissions;
      if (Object.hasOwn(data, 'responsable_id') || Object.hasOwn(data, 'colaboradores_ids')) {
        const responsibleId = String(data.responsable_id ?? current.responsable_id ?? '');
        const collaboratorIds = [...new Set(parseArray(data.colaboradores_ids ?? current.colaboradores_ids).filter((userId) => userId && userId !== responsibleId))];
        const participantIds = [responsibleId, ...collaboratorIds].filter(Boolean);
        if (participantIds.some((userId) => !auth.members.some((member) => member.userId === userId && member.joined))) {
          throw new DomainError('Responsable o colaborador no pertenece al equipo activo.', 400);
        }
        const responsible = auth.members.find((member) => member.userId === responsibleId);
        data.responsable_id = responsibleId;
        data.responsable = responsible?.userName || 'Sin asignar';
        data.colaboradores_ids = JSON.stringify(collaboratorIds);
        permissions = readPermissions({ responsable_id: responsibleId, colaboradores_ids: collaboratorIds }, teamId);
      }
      if (Array.isArray(data.checklist)) data.checklist = JSON.stringify(data.checklist);
      if (Array.isArray(data.colaboradores_ids)) data.colaboradores_ids = JSON.stringify(data.colaboradores_ids);
      data.modificado_por_id = auth.actor.id;
      stampRealDates(data, current, typeof data.estado === 'string' ? data.estado : null, clock().toISOString());
      const changes = buildChangeSet(beforeData, data);
      const updated = await call(req, pathFor(tasksTableId, `/${encodeURIComponent(activityId)}`), {
        method: 'PATCH',
        body: { data, ...(permissions ? { permissions } : {}) },
      });
      if (Object.keys(changes).length) {
        await writeHistory(req, {
          activityId,
          actor: auth.actor,
          action: 'updated',
          changes,
          activity: rowData(updated),
        });
      }
      return { ok: true, activity: rowData(updated) };
    } finally {
      await releaseLock(req, activityId, executionId).catch(() => {});
    }
  }

  async function addComment(req, payload, auth) {
    const activityId = String(payload.activityId || '');
    const text = String(payload.text || '').trim();
    if (!activityId || !text || text.length > 4000) throw new DomainError('El comentario debe tener entre 1 y 4000 caracteres.');
    const activity = await getRow(req, tasksTableId, activityId);
    authorizeMutation({ role: auth.role, actor: auth.actor, action: 'comment', activity });
    const commentData = {
      actividad_id: activityId,
      usuario_id: auth.actor.id,
      autor_nombre: auth.actor.name,
      texto: text,
      fecha: clock().toISOString(),
    };
    const comment = await createRow(req, commentsTableId, commentData, readPermissions(activity, teamId));
    await writeHistory(req, {
      activityId,
      actor: auth.actor,
      action: 'comment_added',
      changes: { comentario_id: { anterior: null, nuevo: comment.$id } },
      activity,
    });
    return { ok: true, comment: rowData(comment) };
  }

  async function listMembers(req) {
    const response = await call(req, `/teams/${encodeURIComponent(teamId)}/memberships?total=false`);
    const memberships = Array.isArray(response?.memberships) ? response.memberships : [];
    const members = memberships
      .filter((membership) => membership.joined || membership.confirm)
      .map((membership) => ({
        userId: membership.userId,
        nombre: membership.userName || membership.userEmail || '',
        roles: Array.isArray(membership.roles) ? membership.roles : [],
      }))
      .filter((member) => member.userId);
    return { ok: true, members };
  }

  async function updateClient(req, payload, auth) {
    if (!['admin', 'supervisor'].includes(auth.role)) throw new DomainError('Solo administración o supervisión puede editar clientes.', 403);
    const clientId = String(payload.clientId || '');
    if (!clientId) throw new DomainError('Falta el cliente.', 400);
    const allowed = ['dueno_relacion_id', 'responsable_ejecucion_id', 'revisor_id', 'frecuencia', 'plantilla_id', 'dia_vencimiento', 'estado', 'notas'];
    const data = {};
    for (const key of allowed) {
      if (Object.hasOwn(payload.data || {}, key)) data[key] = payload.data[key];
    }
    if (!Object.keys(data).length) throw new DomainError('No hay cambios para guardar.', 400);
    if (data.frecuencia != null && data.frecuencia !== '' && !['mensual', 'trimestral'].includes(String(data.frecuencia))) {
      throw new DomainError('Frecuencia no válida.', 400);
    }
    if (Object.hasOwn(data, 'dia_vencimiento')) {
      const day = Number(data.dia_vencimiento);
      if (!Number.isInteger(day) || day < 1 || day > 28) throw new DomainError('El día de vencimiento debe estar entre 1 y 28.', 400);
      data.dia_vencimiento = day;
    }
    const updated = await call(req, pathFor('clientes', `/${encodeURIComponent(clientId)}`), { method: 'PATCH', body: { data } });
    return { ok: true, client: rowData(updated) };
  }

  function parsePeriod(periodo) {
    const match = /^(\d{4})-(\d{2})$/.exec(String(periodo || ''));
    if (!match) throw new DomainError('El período debe tener el formato AAAA-MM.', 400);
    const year = Number(match[1]);
    const month = Number(match[2]);
    if (month < 1 || month > 12) throw new DomainError('Mes no válido.', 400);
    return { year, month };
  }

  async function generateMonth(req, payload, auth) {
    if (!['admin', 'supervisor'].includes(auth.role)) throw new DomainError('Solo administración o supervisión puede generar tareas.', 403);
    const clientId = String(payload.clientId || '');
    if (!clientId) throw new DomainError('Falta el cliente.', 400);
    const periodo = String(payload.periodo || '');
    const { year, month } = parsePeriod(periodo);
    const clientRow = rowData(await getRow(req, 'clientes', clientId));

    const query = new URLSearchParams();
    query.append('queries[]', JSON.stringify({ method: 'equal', attribute: 'cliente_id', values: [clientId] }));
    query.append('queries[]', JSON.stringify({ method: 'equal', attribute: 'periodo', values: [periodo] }));
    query.append('queries[]', JSON.stringify({ method: 'limit', values: [1] }));
    const existing = await call(req, pathFor(tasksTableId, `?${query.toString()}`));
    const existingCount = Number(existing.total || 0);
    if (existingCount > 0) return { ok: true, conflict: true, existentes: existingCount, creadas: 0 };

    let items = [];
    if (clientRow.plantilla_id) {
      const template = rowData(await getRow(req, 'checklist_plantillas', clientRow.plantilla_id));
      items = parseArray(template.items)
        .map((item) => (typeof item === 'string' ? { texto: item } : item))
        .filter((item) => item && item.texto);
    }
    if (!items.length) items = [{ texto: `Cierre mensual · ${clientRow.nombre || 'cliente'}` }];

    const day = Math.min(Math.max(Number(clientRow.dia_vencimiento || 5), 1), 28);
    const fechaLimite = new Date(Date.UTC(year, month - 1, day, 12, 0, 0)).toISOString();
    let creadas = 0;
    for (const item of items) {
      const responsableId = String(item.responsable_id || clientRow.responsable_ejecucion_id || '');
      const member = auth.members.find((entry) => entry.userId === responsableId && entry.joined);
      const data = {
        titulo: String(item.texto).slice(0, 255),
        cliente: clientRow.nombre || '',
        cliente_id: clientId,
        plantilla_id: clientRow.plantilla_id || '',
        revisor_id: clientRow.revisor_id || '',
        responsable: member?.userName || 'Sin asignar',
        responsable_id: responsableId,
        colaboradores_ids: '[]',
        fecha_limite: fechaLimite,
        estado: responsableId ? 'Asignada' : 'Pendiente',
        prioridad: 'Media',
        descripcion: `Generada automáticamente desde la plantilla del cliente para el período ${periodo}.`,
        departamento: '',
        categoria: '',
        checklist: '[]',
        comentarios: '[]',
        periodo,
        creado_por_id: auth.actor.id,
        modificado_por_id: auth.actor.id,
      };
      const row = await createRow(req, tasksTableId, data, readPermissions(data, teamId));
      const activityId = row.$id || row.rowId;
      await writeHistory(req, {
        activityId,
        actor: auth.actor,
        action: 'generated',
        changes: { periodo, cliente: clientRow.nombre, plantilla_id: clientRow.plantilla_id || null },
        activity: data,
      });
      creadas += 1;
    }
    return { ok: true, conflict: false, existentes: 0, creadas };
  }

  return async function handler(context) {
    const { req, res, error = () => {} } = context;
    if (req.headers['x-appwrite-trigger'] === 'schedule') {
      return res.json({ ok: true, processed: 0, message: 'La programación recurrente todavía no está habilitada.' }, 200);
    }
    try {
      const auth = await authenticate(req);
      if (req.method !== 'POST') throw new DomainError('Método no permitido.', 405);
      const payload = req.bodyJson && typeof req.bodyJson === 'object'
        ? req.bodyJson
        : JSON.parse(req.bodyText || '{}');
      let result;
      if (payload.action === 'members') {
        result = await listMembers(req);
      } else if (payload.action === 'client.update') {
        result = await updateClient(req, payload, auth);
      } else if (payload.action === 'generate') {
        result = await generateMonth(req, payload, auth);
      } else if (payload.action === 'create') {
        if (!['admin', 'supervisor'].includes(auth.role)) throw new DomainError('Solo administración o supervisión puede crear actividades.', 403);
        result = await createActivity(req, payload, auth);
      } else if (payload.action === 'update') {
        result = await updateActivity(req, payload, auth);
      } else if (payload.action === 'comment') {
        result = await addComment(req, payload, auth);
      } else {
        throw new DomainError('Operación no reconocida.', 400);
      }
      return res.json(result, 200);
    } catch (error) {
      if (error instanceof DomainError || error instanceof ApiError) {
        return res.json({ ok: false, error: error.message }, error.status);
      }
      error(error?.message || String(error));
      return res.json({ ok: false, error: 'Error interno del servicio de actividades.' }, 500);
    }
  };
}

export default createHandler();
