import json
import unittest
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "appwrite-schema.json"
TEAM_ID = "6b00345f00250c3d5dac"


class AppwriteSchemaContractTests(unittest.TestCase):
    def setUp(self):
        self.schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
        self.tables = {table["table_id"]: table for table in self.schema["tables"]}

    def test_existing_task_table_is_extended_without_replacing_legacy_fields(self):
        tasks = self.tables["6afee819003db9380092"]
        columns = {column["key"]: column for column in tasks["columns"]}
        self.assertEqual(
            set(columns),
            {
                "titulo", "cliente", "responsable", "fecha_limite", "estado", "prioridad",
                "descripcion", "comentarios", "responsable_id", "colaboradores_ids",
                "fecha_inicio", "departamento", "categoria", "checklist", "creado_por_id",
                "modificado_por_id",
            },
        )
        self.assertEqual(columns["titulo"]["type"], "text")
        self.assertTrue(columns["titulo"]["required"])
        self.assertEqual(columns["cliente"]["type"], "text")
        self.assertFalse(columns["cliente"]["required"])
        self.assertTrue(columns["responsable"]["required"])
        self.assertEqual(columns["responsable_id"]["size"], 36)
        self.assertFalse(columns["responsable_id"]["required"])
        self.assertEqual(columns["fecha_inicio"]["type"], "datetime")
        self.assertFalse(columns["fecha_inicio"]["required"])
        self.assertEqual(columns["colaboradores_ids"]["default"], "[]")
        self.assertEqual(columns["checklist"]["default"], "[]")
        self.assertEqual(columns["creado_por_id"]["size"], 36)
        self.assertEqual(columns["modificado_por_id"]["size"], 36)

    def test_enums_include_requested_values_and_preserve_legacy_values(self):
        columns = {column["key"]: column for column in self.tables["6afee819003db9380092"]["columns"]}
        self.assertEqual(
            columns["estado"]["elements"],
            ["Pendiente", "Asignada", "En proceso", "En revisión", "Observada", "Finalizada", "Cancelada", "Atrasada", "En curso", "Bloqueada", "Completada"],
        )
        self.assertEqual(columns["prioridad"]["elements"], ["Baja", "Media", "Alta", "Urgente", "Normal"])
        self.assertEqual(columns["prioridad"]["format"], "enum")
        self.assertTrue(columns["prioridad"]["required"])

    def test_task_table_restricts_access_to_row_permissions(self):
        tasks = self.tables["6afee819003db9380092"]
        self.assertTrue(tasks["row_security"])
        self.assertEqual(tasks["permissions"], [])

    def test_additive_comment_history_and_lock_tables_are_row_secured(self):
        self.assertEqual(
            set(self.tables),
            {"6afee819003db9380092", "activity_comments", "activity_history", "activity_locks"},
        )
        for table_id in ["activity_comments", "activity_history"]:
            table = self.tables[table_id]
            self.assertTrue(table["row_security"])
            self.assertEqual(table["permissions"], [f'read("team:{TEAM_ID}/admin")'])
        self.assertTrue(self.tables["activity_locks"]["row_security"])
        self.assertEqual(self.tables["activity_locks"]["permissions"], [])
        self.assertIn("texto", {column["key"] for column in self.tables["activity_comments"]["columns"]})
        self.assertIn("cambios", {column["key"] for column in self.tables["activity_history"]["columns"]})

    def test_database_and_existing_table_ids_match_the_verified_project(self):
        self.assertEqual(self.schema["database_id"], "6afee7d600290b7c3a53")
        self.assertEqual(self.tables["6afee819003db9380092"]["name"], "Tareas")

    def test_ui_to_database_mapping_is_explicit(self):
        self.assertEqual(
            self.schema["ui_field_map"],
            {
                "title": "titulo", "client": "cliente", "owner": "responsable",
                "owner_id": "responsable_id", "due": "fecha_limite", "start": "fecha_inicio",
                "status": "estado", "priority": "prioridad", "description": "descripcion",
                "comments": "activity_comments", "checklist": "checklist",
                "department": "departamento", "category": "categoria",
            },
        )


if __name__ == "__main__":
    unittest.main()
